Una promesa es un `objeto` que representa el final de una opearción asincrona. Funciona como una interrupción pero sin necesidad de tener "callbacks anidados" .

Son mas fáciles de manejar, leer y mantener que los callbacks.

Tiene 3 estados:

	1- Pendiente = Pending 
	2- Cumplida = Fullfilled
	3- Rechazada = Rejected

La funcion principal por la que se usan este tipo de objeto es para **operaciones de solicitudes de red, lectura de archivos o cualquier otra operacion que pueda tardar un tiempo en completarse**

La creacion de una promesa sigue las siguientes reglas sintacticas:
```typescript
const myPromise = new Promise((resolve, reject) => {
	const operationSuccess = true;

	if (operationSuccess){
	resolve("Operacion completada");
		}
	else {
	reject (new Error("Operacion Fallida"));
		} 
});
```

Cuando tenemos una promesa podemos usar los metodos `.then()` y `.catch()` para manejar los resultados exitosos o los errores que puedan ocurrir, por ejemplo:
```typescript
myPromise
	.then(result =>{
		console.log("Resultado", result);
	})
	.catch(error =>{
		console.error("Error", error);
	})
```

Con la sintaxis de **async/await** que utilizamos en nuestros codigos smartcontracts y funciones, es mas facil ya que se asemeja mas a el codigo sincrono, por ejemplo:
```typescript
async function performOperation(){
	try{
		const result = await myPromise
		console.log ("Resultado", result);
	} catch (error) {
		console.error ("Error:", error);
	}
}
```


