Cuando estamos trabajando con Javascript o Typesciprt necesitamos utilizar librerias externas que nos proporcionen utilidades para nuestro codigo, funciones ya creadas para aumentar la eficiencia y no depender de crearlas nosotros mismos.

##### TextDecoder
Transforma datos binarios o en este caso datos HEX que nos devuelve la API del smartcontract a datos legibles en `utf-8` (u otros formatos)

La invocacion:
```typescript
const utf8Decoder = new TextDecoder();
```
Esto crea una nueva [instancia] , esto quiere decirque utf8Decoder pasa a ser un nuevo objeto del tipo TextDecoder.

Transforma, por ejemplo un `ArrayBuffer`o un `Uint8Array`que contendrá formato de texto `utf-8` para decodificarlo en formato legible. Ex:
```typescript
const arrayBuffer = new Uint8Array([72,101,108,108,111]); //caracteres del array en formato ASCII
const text = utf8Decoder.decode(arrayBuffer);
//la salida sera "Hello"
```

