Creador del QR code (nose si implementarlo) https://github.com/davidshimjs/qrcodejs


- Buscar articulo o libro divulgativo de blockchain
- Buscar articulo de las bases de datos actuales y como se comportan
- Buscar articulo o referencia de la etimologia de la palabra **tecnologia**
-









-------------

- (Fraiberger, Samuel P. and Sundararajan) Arun, Peer-to-Peer Rental Markets in the Sharing Economy (September 2017). NYU Stern School of Business Research Paper (First version March 2015; current version September 2017), Available at SSRN: [https://ssrn.com/abstract=2574337](https://ssrn.com/abstract=2574337) or [http://dx.doi.org/10.2139/ssrn.2574337](https://dx.doi.org/10.2139/ssrn.2574337)
- The limits of trust-free systems: A literature review on blockchain technology and trust in the sharing economy. https://www.sciencedirect.com/science/article/pii/S1567422318300292#b0365
- A Multi-node Collaborative Storage Strategy via Clustering in Blockchain Network. https://ieeexplore.ieee.org/document/9355650#:~:text=Abstract:%20Blockchain%20is%20essentially%20a,expand,%20the%20data%20rises%20linearly
- Blockchain Technology for Enhancing Supply Chain Performance and Reducing the Threats Arising from the COVID-19 Pandemic. https://www.mdpi.com/2071-1050/14/6/3290
- Blockchain-Based IoT Devices in Supply Chain Management: A Systematic Literature Review. https://www.mdpi.com/2071-1050/13/24/13646
- Efficient Supply Chain Traceability Using IoT Technologies(https://ercim-news.ercim.eu/en119/special/efficient-supply-chain-traceability-using-iot-technologies "Efficient Supply Chain Traceability Using IoT Technologies")
- A Blockchain-Based Product Traceability System with Off-Chain EPCIS and IoT Device Authentication. https://www.mdpi.com/1424-8220/22/22/8680

- Blockchain-Based Internet of Things and Industrial IoT: A Comprehensive Survey. https://www.hindawi.com/journals/scn/2021/7142048/

- How Walmart brought unprecedent transparency to the food supply chain with Hyperledger Fabric, 2022. https://www.hyperledger.org/case-studies/walmart-case-study

- Pekoske, D., 2018. Advanced Integrated Passenger and Baggage Screening Technologies.
GAO: Transportation Security Administration. October: 2-41. Retrieved September
30, 2019. https://www.dhs.gov/sites/default/files/publications/TSA%20-%
20Advanced%20Integrated%20Passenger%20Screening%20Technologies.pdf.

- PIB AMERICA 6% https://www.bea.gov/news/2018/gross-domestic-product-4th-quarter-and-annual-2017-second-estimate
-  Bitcoin Whitepaper https://www.bitcoin.com/bitcoin.pdf
- Reyna, A., Martín, C., Chen, J., Soler, E., Díaz, M.: On blockchain and its integration with IoT.
Challenges and opportunities. Futur. Gener. Comput. Syst. 88, 173–190 (2018)

- Crytographic hash functions: https://link.springer.com/chapter/10.1007/978-3-642-04117-4_4#:~:text=A%20hash%20function%20processes%20an,from%20a%20given%20hash%20value

- Emerging Trends in Blockchain Technology and Applications: A Review and Outlook. https://www.sciencedirect.com/science/article/pii/S1319157822000891?ref=cra_js_challenge&fr=RR-1

- An Overview of Trees in Blockchain Technology: Merkle Trees and Merkle Patricia Tries https://www.researchgate.net/publication/358740207_An_Overview_of_Trees_in_Blockchain_Technology_Merkle_Trees_and_Merkle_Patricia_Tries
- Z. Zheng, S. Xie, H. Dai, X. Chen and H. Wang, "An Overview of Blockchain Technology: Architecture, Consensus, and Future Trends," _2017 IEEE International Congress on Big Data (BigData Congress)_, Honolulu, HI, USA, 2017, pp. 557-564, doi: 10.1109/BigDataCongress.2017.85.
- The Byzantine Generals Problem. https://dl.acm.org/doi/10.1145/357172.357176#:~:text=Pease%20et%20al,possible%20iff%20n
-  Libro Bitcoin and Blockchain Security. Ghassan Karame, Elli Androulaki. https://books.google.es/books?hl=en&lr=&id=YYSuDgAAQBAJ&oi=fnd&pg=PR5&ots=jvWVROdCE5&sig=k9_TSrVMzbN67HeMpkfoI42HYzI&redir_esc=y#v=onepage&q&f=false

- A Survey on Byzantine Agreement Algorithms in Distributed Systems. https://link.springer.com/chapter/10.1007/978-981-19-0011-2_44#:~:text=Byzantine%20Generals%20problem%20leads%20us,the%20effect%20of%20faulty%20processors

- Blockchain without Waste: Proof-of-Stake. https://academic.oup.com/rfs/article-abstract/34/3/1156/5868423#:~:text=This%20paper%20provides%20the%20first,also%20precludes%20a%20persistent

- Elliptic Curve Cryptography and its applications. https://ieeexplore.ieee.org/document/5931464#:~:text=The%20Elliptic%20Curve%20Cryptography%20covers,point%20on%20an%20elliptic%20curve

- Mineria bitcoin https://academy.binance.com/es/articles/how-to-mine-bitcoin?ref=HDYAHEES
- Hyperledger Fabric bloque genesis https://hyperledger-fabric.readthedocs.io/en/latest/configtx.html
-  An overview on smart contracts: Challenges, advances and platforms https://www.sciencedirect.com/science/article/pii/S0167739X19316280
- Wikipedia Smartcontract: https://es.wikipedia.org/wiki/Contrato_inteligente#:~:text=Un%20contrato%20inteligente%20,ciertas%20acciones%20sucedan%20como
- BBVA 5 preguntas smartcontract: https://www.bbva.com/es/innovacion/smart-contracts-cinco-preguntas-clave/
- The Internet of Things: A survey: https://www.sciencedirect.com/science/article/pii/S1389128610001568
- New Blockchain-Based Architecture for Service Interoperations in Internet of Things https://ieeexplore.ieee.org/document/8764459
- Messaging Protocols for IoT Systems—A Pragmatic Comparison https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8540579/
- Internet of things: Conceptual network structure, main challenges and future directions https://www.sciencedirect.com/science/article/pii/S2352864822000827
- **BEUMER GROUP HOW DID THE BAGGAGE HANDLING SYSTEM DEVELOPED TRU THE YEARS - https://www.beumergroup.com/knowledge/airport/how-did-the-baggage-handling-system-develop-and-which-systems-are-used-in-airports-today/**
- **Bradley, Alexandre. "A comparison of whole life cycle costs of robotic, semi-automated, and manual build airport baggage handling systems." (2013).** https://files.core.ac.uk/pdf/23/29409858.pdf
- 6 tecnologías que están revolucionando la experiencia de vuelo en los aeropuertos de todo el mundo https://mex.nec.com/es_MX/press/PR/20190221064809_28823.html
- Aeropuertos inteligentes: aceptación de la tecnología por parte de los pasajeros https://www.researchgate.net/publication/343030041_Aeropuertos_inteligentes_aceptacion_de_la_tecnologia_por_parte_de_los_pasajeros


- An in-depth investigation of the performance characteristics of Hyperledger Fabric https://www.sciencedirect.com/science/article/pii/S0360835222007045#:~:text=With%20the%20use%20of%20this,while%20also%20considering%20varying%20workloads

- **HYPERLEDGER FABRIC https://www.ibm.com/es-es/topics/hyperledger
- Enterprise Blockchain Protocols: A Technical Analysis of Ethereum vs Fabric vs Corda https://www.kaleido.io/blockchain-blog/enterprise-blockchain-protocols-a-technical-analysis-of-ethereum-vs-fabric-vs-corda#:~:text=For%20these%20permissioned%20chains%2C%20three,designed%20for%20the%20financial%20industry

- Permissioned blockchain frameworks in the industry: A comparison https://www.sciencedirect.com/science/article/pii/S2405959520301909?via%3Dihub
- ¿Qué es MQTT? - https://aws.amazon.com/es/what-is/mqtt/
- A walkthrough of the emerging IoT paradigm: Visualizing inside functionalities, key features, and open issues. https://www.sciencedirect.com/science/article/pii/S1084804519302188
- A survey on communication protocols and performance evaluations for Internet of Things. https://www.sciencedirect.com/science/article/pii/S2352864822000347
- Raft protocol paper https://raft.github.io/raft.pdf
- Hyperledger fabric: a distributed operating system for permissioned blockchains: https://dl.acm.org/doi/10.1145/3190508.3190538
- What is a SAN (subject alternative name) and how is it used? https://www.entrust.com/blog/2019/03/what-is-a-san-and-how-is-it-used/
- A comprehnsive survey on smart contract construction and execution: https://pdf.sciencedirectassets.com/776857/1-s2.0-S2666389920X00122/1-s2.0-S2666389920302439/main.pdf?X-Amz-Security-Token=IQoJb3JpZ2luX2VjEMH%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLWVhc3QtMSJHMEUCIBaq8gzDKZHNCult9c5KmnZENaG9FOXN6adpSne4tT70AiEAkXUWhBG60ZZT1z2HBMK%2FuzKFDHeEOgbMCBYTHTx5QhsqswUIGhAFGgwwNTkwMDM1NDY4NjUiDPWY%2BwHeVO1bS%2Fz8TyqQBaCECU%2B%2Fbx5SGpOt6FsnhLEUKgsm9IVdGr2fXZ0qJQp4UstdbCzs3W%2BDBqHoAH3RW1nTVSOMilK8S2ncDsc06xyHivpdouFzmE59FgUOWV1%2FN%2BMsl2xukomB5sSLcvTSGZZtE69sqLVxe4LDz%2Bo%2FK%2FzMxWWU2%2FNhORe5CnL8sTklQDHMQrCLbfOUlgboF2dCIdCg88vVsoRSW%2FSfVP2UKGstqPscPWz2C1V2OV%2BlMzF3CZxx%2Fbz5VkgCBjbTFkc36YAXmDnX2CZw8Oc2GkEGM4ziAwozdWV43LfwGZn4uyrOZGT5Uy485Le5msRBmX1Q0AwHwbSjvJtjRFTP%2BaldTbV36DBc3B9vuDiw5uauNwaVMUc9DoXjPn98hsQvcpereDK1zGTeg%2B%2F2SHbGt0H9eV2UE4T568bCsR2bOxdaqxQt4dDPqvCUQwTzs22hLc5LkQLLtdwOooBhdOdIsdmaHaLApYHi937TVfhvz%2BPnQq5erPozm7AGKiMIH2lyzM6NfWdY7VpAhlgm5d4Va8YQ5Cy2V132Dj37ExassW7qSGK63jVNA6t4JHaMgzi0D4QrpHo29Sjv47Q%2FEdDs2gq2y5lt7TDm0viXE0G4XfIbXkanwjhwL3XcZuekmjRKWgy7ORo3a7xXK%2BUDppwiMPJQj1SCQ5glA2jFgOmoZGhnfAosNbJy6xogwM3feIWVwTM5Qjh0vUOm1GjCaulfesZ1ffxiolH0XOIwwFfAMERHvUgVgpK2ZsYr3MCv%2BE7FEsYxcKuTbVzh3Nxd%2F8HKwRmMcmhmkONXqY3gKyG7NXCD2nS5AZDiNMk8il9LsrIPTPIiQQXPIoK%2BkN1x5Q9CccwEU9KTPMweWVaoVRceN%2Ft0OboOMLLD86oGOrEBqNAhrH%2Fmu9%2FJbb7Y0ofXDJvRxpVWue%2BxEpkRUe1XSvbkJADUaYnymvmxoc2cibhSlqD2BNJ93u8FxJNwNAA96cln14QL9M31MSHA%2Bk1ITC2ooQ8vFRLs9EtpCxtS%2FDp1OdspFYfc3Xf9KpL5DuT5fI3wZmLoLkIkiaH%2FxvOdbrH0PwO6LNq4%2FqEIpM6hXw%2FqV1RWN2nwRgiYELAc2wQt1dRN2ToTyXtUl48inoBQ%2BEjW&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20231121T175953Z&X-Amz-SignedHeaders=host&X-Amz-Expires=300&X-Amz-Credential=ASIAQ3PHCVTYVOCXCHPM%2F20231121%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=608046512b7bfff7a64fda9db681e2a9d84b412c64bb48077d65a1248cb5c651&hash=b492570091edd924a0cdf5920f56b99968b36300456c63e4bc4e229bbe93752e&host=68042c943591013ac2b2430a89b270f6af2c76d8dfd086a07176afe7c76c2c61&pii=S2666389920302439&tid=spdf-b8a21515-490b-43bc-b39b-143423369ad7&sid=59e2478b489306435f6bc4174b62f3f9df0egxrqb&type=client&tsoh=d3d3LnNjaWVuY2VkaXJlY3QuY29t&ua=031056555f0f055150&rr=829ad43b8cc865fa&cc=es
  
  