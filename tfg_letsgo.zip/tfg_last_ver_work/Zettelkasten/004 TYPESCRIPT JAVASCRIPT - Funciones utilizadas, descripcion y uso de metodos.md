Teniendo como referencia la función:
```typescript
export async function readAssetMethod (contract: Contract, assetName: string){
	const result = await contract.evaluateTransaction('readAsset',assetName);
	const decodeToJsonResult = utf8Decoder.decode(result);
	console.log ("La funcion, readAssetMethod a sido enviada, el resultado de la operacion es: ", decodeToJsonResult);
	return JSON.parse(decodedToJsonResult);
}
```

Tenemos que diferenciar cada parte de la funcion:

- `export`
	Se utiliza para exportar una funcion y que pueda ser utilizada por otros archivos a la llamada.
- `async`
	Se utiliza para que la función devuelva una [[001 Promesa|Promesa]], en el contexto de Hyperledger Fabric, como los smartcontracts pueden tardar un tiempo en ejecutarse debido a latencias de red, la necesidad de alcanzar consenso con nodos etc, se utilizan esas funciones asincronas cuando se requiere llamar al metodo que ejecuta el chaincode.
+ `function`
	Es la sintaxis utilizada para crear funciones y definirlas.

Despues de esto, tenemos la linea de 
```javascript
const result = await contract.evaluateTransaction('readAsset',assetName);
```
En este caso `result` se decodifica ya que `evalueTransaction` devuelve un buffer que se necesita convertir a formato `utf8`para que sea una cadena de texto legible.


Y la utlima parte del codigo:
```javascript
return JSON.parse(decodedToJsonResult);
```

Nos deveuleve la decodificacion parseada de forma de que podamos leerla como si fuese un objeto, por ejemplo:
```javascript
const jsonString = '{"name": "Alberto", "age": "20", "city": "Sevilla"}'
```

Con esto, podriamos unicamente imprimir por pantalla la cadena completa, ya que la estamos tratando como una `string`, si hacemos `console.log(jsonString)` obtendriamos la cadena completa, pero si utilizamos el metodo:
```javascript
const jsonObject = JSON.parse(jsonString);
```

Podemos ahora llamar al objeto por sus propiedades, y por ejemplo:
```javascript 
console.log(jsonObject.name) //Alberto
```










