
Muy importante esto para ejecutar el CLI del peer como admin y poder hacer todas las operaciones necesarias 


``` bash
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_LOCALMSPID="Org1MSP"
export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=../cryptogen/crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp
export CORE_PEER_ADDRESS=localhost:7051
```


### Este comando para unir al peer con el canal:
```bash
./peer channel join -b ../genesis/genesis_block.pb --tls --cafile ../cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem --certfile ../cryptogen/crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/server.crt --keyfile ../cryptogen/crypto-conf
ig/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/server.key
```

Hay que colocar la identidad de admin CORE_PEER_MSPCONFIGPATH a *admin*:
```bash
export CORE_PEER_MSPCONFIGPATH=../cryptogen/crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp

export CORE_PEER_MSPCONFIGPATH=/home/alber/HLF_0.1/cryptogen/crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp

```

### Crear bloque genesis, unir peers y seleccionar un anchor-peer
Para crear el *bloque genesis:*
```bash
./configtxgen -profile ChannelDeveloper -outputBlock genesis_block.pb -channelID channel1
```

Para unir el *orderer con el bloque y crear un canal*
```bash
./osnadmin channel join --channelID channel1  --config-block ../genesis/genesis_block.pb -o 127.0.0.1:6003
```
Ya podemos unir nuestro peer:
```bash
./peer channel join -b ../genesis/genesis_block.pb --tls --cafile ../cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem --certfile ../cryptogen/crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/server.crt --keyfile ../cryptogen/crypto-conf
ig/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/server.key
```

##### Despues de unir nuestro primer peer que sera el principal, tenemos que asociarlo como *ANCHOR-PEER*

Primero, conseguimos la config del bloque 0 que es la config del bloque genesis para modificarla:
```bash
./peer channel fetch config channel-artifacts/config_block.pb -o orderer.example.com:6001 --ordererTLSHostnameOverride orderer.example.com -c channel1 --tls --cafile ../cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem

```
Decodificamos el primer bloque que esta en forma protobuff a JSON:
```bash
./configtxlator proto_decode --input genesis_block.pb --type common.Block --output genesis_block.json


jq '.data.data[0].payload.data.config' genesis_block.json > config.json

```
Copiamos config:
```bash
cp config.json config_copy.json

```
Ayadimos la config del peer0 para que sea ANCHORPEER:
```bash
jq '.channel_group.groups.Application.groups.Org1MSP.values += {"AnchorPeers":{"mod_policy": "Admins","value":{"anchor_peers": [{"host": "peer0.org1.example.com","port": 7051}]},"version": "0"}}' config_copy.json > modified_config.json
```

Convertimos otra vez a protobuff y ayadimos al nuevo bloque genesis para su posterior injeccion:

```bash
./configtxlator proto_encode --input config.json --type common.Config --output config.pb


./configtxlator proto_encode --input modified_config.json --type common.Config --output modified_config.pb


./configtxlator compute_update --channel_id channel1 --original config.pb --updated modified_config.pb --output config_update.pb


```


Nuestro archivo *config_update.pb* contiene ya la config del anchor peer 
```bash
./configtxlator proto_decode --input config_update.pb --type common.ConfigUpdate --output config_update.json

echo '{"payload":{"header":{"channel_header":{"channel_id":"channel1", "type":2}},"data":{"config_update":'$(cat config_update.json)'}}}' | jq . > config_update_in_envelope.json

./configtxlator proto_encode --input config_update_in_envelope.json --type common.Envelope --output config_update_in_envelope.pb
```

Updateamos la configuracion del canal para anyadir al canal mediante el peer0 la nueva configuracion:
```bash
./peer channel update -f channel-artifacts/config_update_in_envelope.pb -c channel1 -o orderer.example.com:6001  --ordererTLSHostnameOverride orderer.example.com --tls --cafile ../cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem

```

### Creamos el chaincode, buildeamos con el peer
```bash
./peer lifecycle chaincode package basic.tar.gz --path /home/alber/HLF_0.1/peer0/basic5.tar.gz --lang node --label basic_1.0

```
### Instalar el chaincode en el peer
```bash
./peer lifecycle chaincode install basic.tar.gz
```

### Exportamos variable CC_PACKAGE
```bash
Se exporta la variable con el codigo del chaincode instalado, por ejemplo:

basic0.2:7bde523e840d016b99c271c65cd2554d49a5c3e39c5f9ef47e7f4a274345ab79

export CC_PACKAGE_ID=basic0.2:7bde523e840d016b99c271c65cd2554d49a5c3e3...
```


### Hacer el appove en los peers definir el chaincode en el canal

```bash

@ El codigo inferior es para 1 peer, ya que todos estan en la misma org, con que 1 lo apruebe ES SUFICIENTE:

./peer lifecycle chaincode approveformyorg -o orderer.example.com:6001 --ordererTLSHostnameOverride orderer.example.com --channelID channel1 --name basic --version 1.0 --package-id $CC_PACKAGE_ID --sequence 1 --tls --cafile ../cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem
```

### Comprobamos el estado del chaincode en nuestra organizacion, si esta aprobado o rechazado

```bash

./peer lifecycle chaincode checkcommitreadiness --channelID channel1 --name basic --version 1.0 --sequence 1 --tls --cafile ../cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem --output json


```
### Si ya esta aprobado, hacemos el commit en la organizacion

```bash

./peer lifecycle chaincode commit -o orderer.example.com:6001 --ordererTLSHostnameOverride orderer.example.com --channelID channel1 --name basic --version 1.0 --sequence 1 --tls --cafile ../cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem --peerAddresses peer0.org1.example.com:7051 --tlsRootCertFiles ../cryptogen/crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt


```
### Volvemos a ver el querycommit
```bash
./peer lifecycle chaincode querycommitted --channelID channel1 --name basic --cafile ../cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem

```
### Ya podemos hacer el invoke

```bash
./peer chaincode invoke -o orderer.example.com:6001 --ordererTLSHostnameOverride orderer.example.com --tls --cafile ../cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem  -C channel1 -n basic --peerAddresses peer0.org1.example.com:7051 --tlsRootCertFiles ../cryptogen/crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt -c '{"function":"InitLedger","Args":[]}'

```
### Si todo esta bien, podemos ejecutar los comandos de nuestro chaincode desde el CLI

```bash

./peer chaincode query -C channel1 -n basic -c '{"function":"readAsset","Args":["alberto"]}'
```