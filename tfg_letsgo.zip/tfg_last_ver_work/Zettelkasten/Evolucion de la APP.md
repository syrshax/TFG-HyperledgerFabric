En la direccion: 
`/home/alber/backup2/trazability-HLF/` 
Esta el proyecto.


### EL BACKEND.
#### ESP32 NUMERO 1, LECTOR QR DE ENTRADA
Ya esta creada la funcion que hace que cuando cada vez que se lee un codigo QR con las caracteristicas:

	ID: (USUARIO EXISTENTE)
	TRIPID: (ID DEL VIAJE)
	BAGID: (MALETA CON ID)

Si alguno de estos 3 datos esta mal el smartcontract no funciona. Para ello el usuario tiene que registrarse como usuario, rellenar los campos necesarios para crear un viaje y posteriormente añadir el numero de maletas con un ID correspondiente. Esto generará un codigo QR que se pegará en la maleta para hacer la trazabilidad constante en toda la cadena.

Ya hemos conseguido que el ==ESP32 numero 1== haga el proceso de verificacion de forma autonoma cada vez que se le presente un codigo QR por delante.

La forma de enviar la informacion con los otros 2 sensores sera analoga.

Crearemos una funcion del mismo estilo y rellenaremos los campos de `stage2` o `stage3` segun correspondan. Con esto conseguiremos enviar la infomacion de forma autonoma.


El proceso del usuario como he mencionado anteriormente tiene que ser:

##### FRONT END PARA EL USUARIO.

Aqui el usuario creara su ID, en este caso sera su usuario para los viajes. Posteriormente añadira viajes a su historial. Cuando añada un viaje debera introducir la informacion de su origen y destino. El ``tripID`` se autogenerara.

Cuando se crea el viaje tambien se tiene que rellenar la informacion del numero de maletas que quiere trackear. Para ello indicara el numero de maletas y se le asignara un ``bagID`` a cada maleta.

Este ``bagID`` esta relacionado con el ``tripID`` y el ``tripID`` con el ``userID`` : 

							userID -->
													tripID --->
																					bagID

Con toda esta informacion ya generada por el usuario, su historial sera:

![[001idstructureID.png]]


Por lo que la informacion del QR contendra los datos identificativos mencionados anteriormente que seran los necesarios para:

	- SABER A QUE USUARIO SE DIRIGE
	- SABER A QUE VUELO SE DIRIGE
	- SABER A QUE MALETA DENTRO DE ESE VUELO SE DIRIGE

