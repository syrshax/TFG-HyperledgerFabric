

Ya teniendo definidos y presentados los conceptos claves, comenzaremos indagando en la realizacion de **la prueba de concepto** de nuestra **aplicacion de tracking de maletas**.  

La metodologia de desarollara de la siguiente manera:

- **Arquitectura del sistema**: Desde una perspectiva de usuario a alto nivel, se describirá como se va a organizar la estructura de la red y cuales van a ser todos los elementos implicados.
- **Creación de una red blockchain escalable utilizando Hyperledger Fabric.** Comentaremos el funcionamiento en concreto de **Hyperledger Fabric**, sus peculiaridades, configuraciones necesarias y la puesta en marcha de una red para uso funcional.
- **Implementación de Smart Contracts y Adquisición de Datos mediante IoT.**  Describiremos las funciones principales de nuestro smartcontract que hacen posible la transmision y guardado de información y a su vez, ilustaremos como los microcontroladores **Espressif ESP32 WROVER** se conectan, transmiten y captan la información mediante 2 cámaras **OV2460** y una galga extensiometrica **HX711**. 
- **Implementacion e Interconexion del Gateway con la Dapp** . Finalmente configuraremos un puente o gateway para conectar nuestra **blockchain** con nuestra interfaz de usuario y los datos recopilados de los microcontroladores, quedando definida completamente la aplicacion.


Teniendo claro nuestros procedimientos, vamos a definir la cuestion de **la prueba de concepto**. 

Lo que se pretende con esta prueba es, utilizar una arquitectura blockchain como **Hyperledger Fabric**, para demostrar que es mas que posible crear una **aplicacion de tracking de maletas** donde toda la información que se registra, queda almacenada en la blockchain, con todas las ventajas e inconvenientes que esto supone.

El funcionamiento de la aplicacion es simular un registro de equipajes y el respectivo tracking de dichas maletas durante toda la etapa de vuelo, desde el origen hasta el aeropuerto de destino.

El proceso es el siguiente:

- El usuario previamente se registra dentro de la **Dapp**. Esto crea una identidad en la blockchain donde se almacenaran todos sus datos.
- Dentro de la **Dapp**, el usuario indica su nombre, su origen y destino de vuelo y añade las maletas que desea registrar con una breve descripcion. Cuando el usuario confirma su informacion, los datos se registran y se genera un codigo QR para cada una de sus maletas registradas.
- Despues de que el usuario se registre, el obtiene sus identificadores en forma de etiqueta QR. Las maletas pasan por un lector de codigos QR para hacer el primer **check**, despues llegan a un mostrador donde mediante la galga, la maleta se pesa y se registra el peso obtenido. Aqui se debe introducir de forma manual el identificador de usuario, viaje y maleta. Por ultimo, en el aeropuerto de destino, se vuelve a leer el código QR, confirmando la recepcion de la maleta.



![[diagrama_programa_inicial_1.png]]

Todos estos hitos comforman el ciclo de vida de la maleta, con todas sus respectivas etapas. En este punto el usuario puede saber en que momento exacto quedo registrada su maleta por cada chequeo, cada paso en la cadena logistica pudiendo verificar si ha tenido algun tipo de retraso o si su maleta se a extraviado en el proceso.

### Blockchain basada en Hyperledger Fabric

Antes de entrar al detalle con nuestra implementacion de la prueba de concepto **aplicacion de tracking de maletas**, debemos conocer de forma mas profunda las bases de funcionamiento y elementos que componen **Hyperledger Fabric** (**Fabric** apartir de ahora )

Como hemos comentando el capitulo anterior, Fabric es una DLT (distributed ledger tecnhology) de codigo abierto, permisionada y privada, que permite la utilizacion de sus propios **smartcontracts** definidos como **chaincodes**, programables con lenguajes de uso general como **Java, Go y Node.js** 

La estructura que presenta Fabric es una union de **nodos** interconectados que almacenan y mantienen una copia del **ledger** actual. Estos nodos participan en uno o varios **canales**, cuyo proposito es funcionar como una subred privada que contiene su propio libro mayor de transaciones. El comportamiento de los nodos en canal se define en la configuración del **bloque génesis** . 

Este conglomerado de nodos puede encapsularse en **organizaciones** (estas organizaciones pueden englobar a nodos que realizan funciones especificas, o para tener diferenciados nodos de diferentes entidades que participen en un mismo canal). Las organizaciones permiten definir diferentes tipos de usuarios, ya sean nodos, clientes, o administradores, quedando definidos los integrantes que la componen y cual es la funcion dentro de la organizacion. 

Todo ello gobernado mediante un **protocolo de consenso** que registra unicamente las transacciones que son validas y han sido confirmadas por los demas nodos de la red.

![[Pasted image 20231114183229.png]]

Una de las grandes ventajas de Fabric es la alta modularidad y versatilidad que nos ofrece. Podemos visualizar desde una perspectiva en alto nivel los siguientes elementos modulares que la componen:

- Un **sistema de ordenación** intercambiable se encarga de alcanzar un consenso sobre el secuenciamiento de las transacciones, para luego distribuir los bloques a los nodos de la red.
- Un **sistema de gestión de membresías** intercambiable que vincula a las entidades de la red con identidades basadas en criptografía.
- Un **peer-to-peer gossip service**, que es opcional, se ocupa de repartir la información de los bloques al solicitarlo a otros nodos.
- Los **contratos inteligentes**, conocidos como "chaincode", operan dentro de un entorno de contenedor, como Docker, proporcionando aislamiento. Estos pueden ser desarrollados en lenguajes de programación convencionales y están diseñados para no interactuar directamente con el estado del libro de contabilidad.
- El **libro de contabilidad** se configura para ser compatible con diferentes sistemas de gestión de bases de datos.
- Un **sistema de aplicación de políticas de validación y respaldo**, que es intercambiable y puede configurarse de manera independiente para cada aplicación.
https://hyperledger-fabric.readthedocs.io/es/latest/ (introduccion)


Al ser Fabric una blockchain privada, los usarios, nodos, servicios, etc. que deseen participar en la red, deberan verificar su identidad mediante un certificado de autenticacion que es proporcionado por un administrador existente o por una autoridad de confianza, Fabric denomina esta autoridad como **MSP** (Membership Service Provider). Este documento es una identidad criptografica basada en un **certificado digital X.509** que identifica a usuarios, nodos, aplicaciones... y ademas determina los permisos y  que estos elementos tienen dentro de la blockchain.

-----------

Quedando introducido la forma de operar y la metodologia de funcionamiento de Fabric, vamos a describir los nodos, que son el elemento principal de las redes basadas que se basan en Hyperledger Fabric. Los **nodos** se pueden clasificar en 2 tipos:

- **Peers**: Es la unidad minima de la red. Son los encargados de guardar una copia del libro de cuentas del canal en el que participan y de ejecutar los **chaincodes**. Cada peer, dependiendo la configuracion, pueden actuar de diferente forma, siendo estos los diferentes tipos:
	- Anchor peer: Siempre tiene que haber un peer con esta configuracion en el canal. Es el encargado de hacer de puerta de enlace con diferentes canales dentro de la organizacion a la que pertenece.
	- Endorsing peer: Tienen la capacidad de registrar transaciones y ejecutar los chaincodes en el canal.
- **Orderer**: Unidad encargada de mantener y organizar los registros y transaciones del canal en el que participa. El orderer es el encargado de introducir la informacion de las transacciones en la red  y consensuar su registro. En la version que utilizamos de Hyperledger Fabric 2.5, se utiliza el protocolo de consenso Raft que asegura consistencia y el orden de las transaciones en el canal. El protocolo Raft es utilizado en clusters de orderers para mantener un consenso en quien debe ser el lider que orqueste las operaciones, actuando basandose en un protocolo tolerante a fallos (CFT). Es un tipo de sistema de computación diseñado para seguir funcionando correctamente en el caso de que uno o más de sus componentes fallen.

![[Pasted image 20231114192125.png]]


La figura superior muestra una arquitectura generica de Fabric. Se define una red donde cada elemento tiene su certificado de autenticidad proporcionado por el MSP. Esta red tiene clientes que emiten transacciones a los **peers** estos publican una transacion en el canal, a la espera de que el **orderer** la valide y la escriba en el libro de cuentas. Despues, se replica en todos los demas peers que guardan una copia del ledger. Se comunican todos atraveś de un mismo **canal**.

La secuencia de transaccion entre nodos de la red en mas detalle es la siguiente:

- Comenzamos invocando alguna funcion de un **chaincode** instalado en la red o simplemente lanzamos una peticion sencilla de escritura.
- En la etapa marcada como 1 en la figura inferior, los **endorsing peers** son los encargados de firmar esta transaccion, una a una, de forma independiente.
- Despues, se aglutinan y se espera a todas las transacciones firmadas por los **endorsering peers** en el lado del cliente.
- Desde el cliente, se envian estas transacciones al **orderer**, que se encarga de validar y comprobar si los peers que han firmado estas transacciones estan validados en el canal.
- Por ultimo, el **orderer** da la señal a **todos los peers** para que escriban la transaccion en el libro de cuentas. 

![[Pasted image 20231114193207.png]]
![[Pasted image 20231115162916.png]]

Hyperledger fabric: a distributed operating system for permissioned blockchains: https://dl.acm.org/doi/10.1145/3190508.3190538



#### Arquitectura del sistema

Conociendo la estructura básica de Fabric y como se comunican los nodos de la red, vamos a explicar en concreto la arquitectura de nuestro concepto de **aplicacion de tracking de maletas**.

La arquitectura de red que seguiremos es la siguiente:

- Tendremos 3 **peers** que estarán dentro de una organizacion denominada **PeerOrg**
- Utilizaremos un unico **orderer** engargado de validar las transacciones. Estará dentro de una organizacion denominada **OrdererOrg**.
- Estos elementos se conectarán a un unico canal que compartiran, por definicion, el mismo **ledger** entre los **peers**.
- Cada organizacion, peer y orderer, tendrá su propio material criptografico generado previamente. Quedando los elementos identificados dentro de la red.

![[Pasted image 20231115170800.png]]


Esta seria la estructura que vamos a seguir teniendo unicamente encuenta la estructura de la red. Dos organizaciones, **peerOrg1** con todos los peers y **OrdererOrg** que incluiria nuestro unico **orderer**. Todos nuestros nodos estaria comunicandose atraves del canal **channel 1**.

A cada **peer** se le conectarán tres **ESP32** que son los encargados de recopilar los datos de entrada en nuestro sistema, dos de ellos se encargarán mediante una camara de detectar cada maleta leyendo su codigo QR y el último de obtener el peso de las maletas. Ellos enviarán la informacion captada por los sensores al host donde están alojados los peers **peers**. El host trabajará los datos conmunicandose con el **peer** y actuara con la informacion proporcionada según se establezca en el **chaincode** (smartcontract). Además, tendremos nuestra **dApp cliente** con la que podremos interactuar y hacer peticiones a la red, ejecutando las funciones programadas en nuestro **chaincode**.

La estructura, incluyendo estos ultimos elementos, quedaria de la siguiente manera:

![[Pasted image 20231115172156.png]]


Este seria el modelo final. Por una parte tenemos la Dapp cliente que se comunica con los peers que son los encargados de recibir las requests y ejecutar las funciones del chaincode. Los ESP32 unicamente envian la información de sus sensores a los nodos peers. Los peers se comunican con el orderer cuando tienen que escribir un nuevo bloque, y es el orderer el valida la transaccion y confirma que el bloque es valido para incluirlo en nuestra blockchain, cuyos encargados de registrarla y guardar una copia del ledger son los **peers**.


### Configuracion de una red blockchain escalable utilizando Hyperledger Fabric

Como ya tenemos nuestra arquitectura planteada, el siguiente paso es consiste en configurar todos los elementos para satisfacer nuestros requerimientos de funcionamiento.

Necesitaremos:

- Crear identidades criptograficas para todos los elementos y organizaciones. Así quedaran definidas en la red.
- Configurar el **bloque genesis**. Este contiene las politicas de funcionamiento, permiso y aplicacion. 
- Configuracion de **peers** y **orderer**. Tamaño maximo de bloques, cuando tiempo deben esperar para hacer una reconexión en caso de fallo...

Fabric se ejecutará bajo una red cerrada LAN, por lo que tendremos que configurar **IP's** de forma manual y asignar los **hostnames** referidos a cada nodo.

##### REQUERIMIENTOS PREVIOS

Para el funcionamiento de Hyperledger Fabric y el de nuestra aplicacion deberemos tener instaldo en siguiente software:
###### SISTEMA OPERATIVO UBUNTU 22.04
Es necesario tener instaldo el sistema operativo **Linux** en todos los nodos de la red, ya que vamos a ejecutar todos nuestros componentes de forma directa "bare bone". Se ha optado en este caso por la versión de **UBUNTU DESKTOP 22-04 LTS**

![[Pasted image 20231118130254.png|500]]


###### DOCKER
Tendremos que tener instalda la ultima version de **Docker**.  Este es utilizado por los peers para crear una maquina virtual donde hostear los **chaincodes**, es decir nuestros contratos inteligentes se instalan dentro de un contenedor de Docker proporcionandoles un entorno aislado que evita interferencias entre dependencias y otros chaincodes existentes. 

**Docker** es una plataforma de virtualización a nivel de sistema operativo. Permite a los desarrolladores empaquetar aplicaciones y sus dependencias en contenedores estandarizados, asegurando que funcionen de manera uniforme en cualquier entorno. 
![[Pasted image 20231118123926.png|300]]

###### GO
Se necesitará tener el lenguaje de programación **Go** instalado. Es el encargado de ejecutar los componentes de Hyperledger Fabric ya que están escritos en este lenguaje. Es un lenguaje de programación moderno, eficiente y de tipado estático diseñado por Google. Es conocido por su simplicidad, eficiencia y capacidad para manejar sistemas concurrentes.

![[Pasted image 20231118124148.png|200]]


###### NODE.JS

Node.js es un entorno de ejecución para JavaScript en el lado del servidor, conocido por su eficiencia y escalabilidad en aplicaciones web. En Hyperledger Fabric, Node.js se utiliza para desarrollar smart contracts (chaincodes) debido a su soporte para JavaScript. Además se ha utilizado para crear el backend de la web y el **Gateway** que conecta la Dapp cliente con la blockchain. Para esto se ha utilizado el lenguaje de programación TypeScript, que no es mas que un superset de Javascript con un tipado estatico, desarrollado por Microsoft.
![[Pasted image 20231118125826.png|300]]]


###### PYTHON
Para nuestro proyecto hemos decicido utilizar la versión de Python 3.11 utilizada junto a varias bibliotecas que nos permiten ejecutar nuestros scipts de toma de datos de nuestros microcontroladores. Por mencionar algunas bibliotecas, **openCV** para la deteccion y lectura de los frames captados por la camara del microcontrolador y **urlib** para la conexion HTTP hacia el host de los peers.

![[Pasted image 20231118130231.png|300]]]


###### Archivos de configuracion .yaml
El formato YAML (YAML Ain't Markup Language) surgió en 2001, desarrollado por Clark Evans en colaboración con Ingy döt Net y Oren Ben-Kiki. Su objetivo era crear un formato de datos fácil de leer y escribir para humanos, a la vez que fuera fácil de analizar y generar para las máquinas. Los archivos `.yaml` estan presentes en la mayoria de los archivos de configuracion que nos encontraremos en Hyperledger Fabric.
![[Pasted image 20231118180707.png]]


###### Binarios y utilidades de Hyperledger Fabric 2.5
En nuestro proyecto hemos optado por utilizar la version de Fabric 2.5, es la version mas actual y estable en la fecha que se realiza este trabajo. Los componentes de Fabric vienen ya compilados y listos para ser ejecutados. Estan escritos en **Go**, por lo que se necesita tener instalado este lenguaje en el ordenador donde se vaya a ejecutar. En nuestro proyecto se van a ejecutar los binarios directamente, sin dockerizacion (los peers si lo utilizan para ejecutar el chaincode) , por lo que es necesario tener instaladas todas las dependencias mencionadas anteriormente.

Los binarios utilizados en Hyperledger Fabric para la version 2.5 se componen de:

- configtxgen : Utilidad para manejar, modificar y crear configuraciones relacionadas con el **bloque genesis**.
- configxlator: Utilidad para procesar y traducir los datos de los bloques a texto y formato legible por el usuario
- cryptogen: Programa destinado para crear identidades criptograficas en redes de desarollo. Es recomendado no utilizarlo bajo ningun concepto sobre redes en produccion.
- orderer: Archivo de ejecucion del orderer.
- peer: Archivo de ejecucion del peer.



##### CREACION DE IDENTIDADES CON MATERIAL CRIPTOGRAFICO

La cuestión de las identidades es una parte que nos afectará durante todo el proceso de instalacion y configuración, ya que para cualquier modificacion que queramos realizar sobre los peers o el orderer, se nos requerirá de que poseamos una identidad validad de admistrador para efectuar cambios, así como los certificados de los elementos a los que queremos acceder.

Para crear todo este material criptografico, Hyperledger Fabric nos provisiona con una utilidad, denominada **cryptogen**,  que mediante un archivo de configuración, seleccionando el numero de peers y orderers que queremos implementar en nuestra red, nos permite de una forma facil crear estas identidades.

Tenemos que especificar un dominio común para nuestras organizaciones, indicar el numero de peers y orderers, un SANS alternativo  https://www.entrust.com/blog/2019/03/what-is-a-san-and-how-is-it-used/si deseamos para nuestras comunicaciones TLS. Aqui tenemos nuestro código de configuracíon:

![[Pasted image 20231118134510.png]]

Seguidamente ejectuariamos nuestra **utilidad cryptogen** indicando mediante flags, el archivo de configuracion y donde deseamos guardar los certificados que genere:
```bash
./cryptogen generate --config="configuracion.yaml" --output="contenido_criptografico"
```

Con esto generariamos dentro de una carpeta llamada contenido_criptografico todos los certificados y claves publico-privadas necesarias para la autentificacion de nuestros elementos en la red.

##### Configuracion del bloque genesis

En Hyperledger Fabric, la configuracion del bloque genesis conlleva tener en ya que se puede definir de muchas maneras y con ello modificar como la blockchain responde y de que manera. Hay que definir en el cuales seran los nombres de nuestras organizaciones, donde estan localizados de forma local sus identidades criptograficas y que politicas tendra esa organizacion dentro del canal. 

Las politicas definiran quien o quienes pueden consultar el libro mayor de cuentas (ledger), que capacidades de escritura/lectura/verificacion tendran los peers dependiendo que identidad se les proporcione, con que autoridad las aplicacicones podran interactuar con el canal, etc.

En este fragmento de codigo, en concreto la configuracion de las politicas de los peers, vemos como se indica el nombre de la organizacion donde esta alojado localmente las identidades criptograficas generadas y las politicas de escritura, verificacion, lectura y administracion. Este archivo de configuracion tiene el nombre de **configtx.yaml**. La configuracion completa realizada para en concreto nuestra aplicacion se encuentra en los **ANEXOS** del documento.

```bash
     Name: Org1
     ID: Org1

     MSPDir: ../organizations/peerOrganizations/org1.example.com/msp

     Policies:
         Readers:
             Type: Signature
             Rule: "OR('Org1MSP.admin', 'Org1MSP.peer', 'Org1MSP.client')"
         Writers:
             Type: Signature
             Rule: "OR('Org1MSP.admin', 'Org1MSP.client')"
         Admins:
             Type: Signature
             Rule: "OR('Org1MSP.admin')"
         Endorsement:
             Type: Signature
             Rule: "OR('Org1MSP.peer')"
```

La parte mas importante aqui son las politicas de la organizacion. Si nos fijamos, dentro de Policies, Readers, nos indica que tiene un Type de Signature. Este tipo de configuracion nos permite seleccionar de forma individual los usuarios que pueden participar en la lectura del canal dentro de la organizacion **Org1**. En concreto, podran leer del canal, todos los usuarios de la organizacion que esten definidos como administradores, peers o clientes.

Aparte de la configuracion de organizaciones, tenemos las politicas de **aplicacion**, politicas del **orderer** y politicas de **canal**, todas ellas con una configuracion muy similar al fragmento de codigo expuesto superiormente.


Cuando terminamos de configurar los parametros, Hyperledger Fabric proporciona una utilidad denominada **configtxgen** que nos genera nuestro bloque genesis con toda la configuracion aportada. El bloque genesis sera necesario posteriormente para indicar a Fabric los parametros iniciales de la red donde tendran que unirse el **orderer** y los peers para poner en marcha nuestra red. 


##### Configuracion de los peers y orderers

Los peers y orderers son las unidades basicas de Hyperledger Fabric. Ambos elementos pertenecen a organizaciones que son miembros del canal al que pertenecen. Los peers se conectan al orderer o servicio de ordenamiento donde exista un cluster de orderers. Los peers tienen smartcontracs instalados y poseen todos una copia identica del ledger del canal o varias copias si pertenecen a mas de un canal, y un **state database** donde se guardan los utlimos valores de los datos del ledger. Con esto pueden acceder de una forma rapida a informacion concurrida sin necesidad de consultar la propia blockchain.

Vamos a abarcar la configuracion principal y minima que se necesita para efectuar de forma correcta una conexion con los demas componentes de la red. No vamos a entrar en detalle en los parametros. La configuracion completa esta situada en el **ANEXO II** del documento.

Los parametros principales a configurar son:

- Identificadores (peers y orderers). Incluyen informacion de donde esta guardada localmente la informacion criptografica, como certificados TLS y el nombre que definira a cada peer y orderer junto con la identidad de la organizacion a la que pertenecen
- Direcciones y archivos del sistema (peers y orderers): Se necesita especificar la direccion IP o dominio del peer y orderer para que puedan ser encontrado por otros componentes de Fabrc. Ademas de indicar donde se guardara la copia del ledger en el caso de los peers y el lugar de instalacion de los smartcontracts
- Protocolo Gossip (peers): Los peers comparten informacion y se comunican mediante este protocolo de aplicacion denominado Gossip. Gracias a el, podemos incluir peers a la red para que sean encontrados y compartan la informacion del canal sin necesidad de efectuar una instalacion completa.

Como se puede observar, la configuracion de los peers es algo mas exahustiva, ya que involucra tambien parametros de configuracion de donde se ejecutan los smartcontracts, parametros del protocolo Gossip o elegir el tipo de DB para el **state database**.

Aqui tenemos un ejemplo de la actual configuraicon

peer0
![[Pasted image 20231118190916.png]]

orderer
![[Pasted image 20231118185555.png]]




##### Union de componentes y creacion de la red
Teniendo todos nuestros elementos configurados correctamente, (siguiendo la guia de configuracion presente en el ANEXO II) vamos a proceder a la interconexion de todos ellos.

Previamente hemos de tener configurados, las direcciones de cada host donde se vayan a alojar los peers, configuraciones y politicas de canal, certificados para la comunicacion TLS entre nodos, etc. Hay que prestar mucha atencion en la instalacion de los certificados, ya que aqui es donde se generan la mayoria de errores cuando queremos iniciar nuestra red por primera vez. 

Para ello debemos tener que tener abierta una consola de comandos (CLI) en nuestro sistema Linux y ir a donde tengamos instaladas nuestras dependencias y archivos del proyecto.

La primera puesta en marcha de la red es bastante tediosa, ya que se deben de configurar uno a uno cada nodo de la red, escribiendo muchos parametros por el CLI, por lo que es bastante facil de equivocarse y tener errores. En este fragmento de la memoria vamos a crear el bloque genesis, unir un peer y un orderer al canal. La creacion de la red completa y comandos utilizados para montar la red, quedan reflejados para consulta en el **ANEXO III** del documento.

---------


El primer paso es cargar en nuestro entorno el certificado de administrador que se creo en el apartado de **creacion de identidades**. Con este certificado podemos ejectuar comandos sobre los propios **peers** y **orderers**, ya que sin el no estariamos autorizados. Recordemos que en la configuracion de los nodos, se incluyo la direccion que apuntaba donde se alojaba todo el material criptografico identificativo de cada nodo y de las organizaciones a las que pertenecen. 

Con este comando exportamos la identidad de admin a CORE_PEER_MSCONFIGPATH como variable de entorno. Con esto sobreescribimos el material criptografico existente en el peer, identificandonos como administrador:
```bash
export CORE_PEER_MSPCONFIGPATH = ../users/Admin/msp
```


Siendo ya administradores, podemos hacer cualquier cambio y ejectuar comandos en el CLI. Vamos ahora a generar el **bloque genesis del sistema**. Nos dirigimos a la carpeta donde tenemos alojada nuestra configuracion, y utilizamos la utilidad de Fabric **configtxgen**:

```bash
./configtxgen -profile ChannelDeveloper -outputBlock genesis_block.pb -channelID channel1
```

Seleccionamos el perfil de configuracion que hemos definido, generamos el bloque con nombre ``genesis_block.pb`` y le ponemos nombre un nombre al canal ``channel1``

Con esto, generariamos nuestro **bloque genesis** y quedaria listo para que un orderer se conectase a el y comenzara a gestionar transacciones.

![[Pasted image 20231121172843.png]]

Para ello, nos dirigimos a la carpeta donde tenemos nuestros orderer configurado y lo iniciamos con:
```bash
./orderer start
```
 Para interactuar con el orderer, Fabric proporciona una utilidad llamada **osadmin** (orderer system administrator) que nos permite ejectuar comandos teniendo como objetivo un orderer en red. En los parametros tenemos que incuir el comando de ``channel join`` para decir que queremos efectuar la funcion de unirnos al canal, indicar el nombre del canal al que queremos unirnos, seleccionar donde esta localizado el **bloque genesis** localmente (recordemos que el bloque genesis es el primer bloque de la red, donde se incluye la configuracion de politicas y permisos del canal) y la direccion IP del orderer al que lanzamos esta orden. El comando completo resultaria en:
```bash
./osnadmin channel join --channelID channel1  --config-block ../genesis/genesis_block.pb -o 127.0.0.1:6003
```


Comprobamos en el CLI que el orderer se a iniciado correctamente:
![[Pasted image 20231121172538.png]]

Por lo tanto, siguiendo a la figura de la arquitectura, ya tendriamos el orderer conectado a nuestro canal:
![[Pasted image 20231121172802.png]]


Apartir de este ahora, el orderer es el encargado de validar y transmitir las transacciones en bloques que los peers vayan a generar, quedaria unir el peer, (peer0) al canal.

Los peers se unen al canal de la misma forma que el orderer, solo que se deben aportar mas argumentos en el comando de union ya que interactuan tanto con el canal como con el orderer u orderers que lo administran.

Para ello, debemos estar en la carpeta donde se encuentre nuestro peer y su configuracion y lanzamos este comando en el CLI:
```bash
./peer node start
```
Este comando iniciara el peer con la configuracion establecida dentro del archivo de configuracion ``core.yaml`` que deberia encontrarse en la raiz donde se localiza el binario del **peer**. 


Cuando ya tenemos el peer iniciado, tenemos que ejecutar mediante el CLI la funcion de union al canal existente ya creado. Para ello debemos pasar por el terminal una serie de certificados tanto del peer que queremos conectar como del orderer al que pertenece el canal, asi como el nombre del canal a conectarnos (ya que un orderer puede governar varios canales). Este es el comando para nuestra configuracion basandonos en el **ANEXO II** de la memoria: 
```bash
./peer channel join -b ../genesis/genesis_block.pb --tls --cafile ../cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem --certfile ../cryptogen/crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/server.crt --keyfile ../cryptogen/crypto-conf
ig/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/server.key
```

Con esto tendriamos un inicio satisfactorio de nuestro peer:
![[Pasted image 20231121183506.png]]

Y la red finalmente quedaria definida como se muestra acontinuacion:

![[Pasted image 20231121183716.png]]

Esta es la unidad minima que formaria una red basada en Hyperledger Fabric. Siguiendo el **ANEXO II** del documento, configurariamos la red con los 2 peers restantes para el correcto funcionamiento de nuestra aplicacion final.


----------------


### IMPLEMENTACION DE LOS SMARTCONTRACTS Y ADQUISICION DE DATOS MEDIANTE IOT

Cuando tenemos implementada nuestra red con las configuraciones deseadas, las funciones que nos ofrece nuestra red son las basicas de una red blockchain DLT, registramos informacion en forma de bloques y tenemos un ledger distribuido entre todos los nodos (peers) que componen la red, pero no tenemos una forma facil de interactuar con la informacion que queremos guardar o leer.

Para ello Hyperledger Fabric opto por la posibilidad de implementar smartcontracts o **chaincodes** que permiten generar una logica dentro del canal y capaz de ejecutar funciones que hayamos creado, a demanda o mediante activacion por eventos.

Esto nos permite crear una logica dentro de nuestra blockchain que puede efectuar cambios cuando por ejemplo queramos registrar a un usuario, cuando queramos leer de cierto parametro algunos de los datos especificos que tenemos registrados o si deseamos transferir informacion de un cliente a otro.

Los smartcontracts o **chaincodes** en Fabric son instalados en cada **peer** del canal. No solo el ledger y el **world state** estan replicados en los peers, tambien los chaincodes, asegurando que cualquier nodo puede ejecutar las funciones del canal al que pertenece independientemente de a cual enviemos la llamada. Esto es posible dependiendo de las politicas de endorso o validacion que configuremos. Estas indican que organizaciones deben firmar las transacciones para considerarlas validas. Hasta que la transaccion no se considera validada no se modifica el **world state**. Aquie es donde se definen las reglas por las cuales diferentes organizaciones pueden transaccionar. 
En nuestra aplicacion en concreto, esto no sucede, ya que nuestra organizacion de peers **PeerOrg** se encarga en su totalidad de gestionar los datos e informacion y validarla en nuestra blockchain, ya que es una aplicacion de desarollo.
En cambio si por ejemplo nuestro **smartcontract** sirva para firmar la compra-venta de un coche, es logico que ambas partes (org1 = comprador, org2 = vendedor) validen la transaccion y solo así se efectuaria la compraventa.

![[Pasted image 20231122192406.png]]
Figura que manifiesta un contrato, las organizaciones que participan en el y descripcion de la transaccion. https://hyperledger-fabric.readthedocs.io/en/release-2.5/smartcontract/smartcontract.html

----------

Tenemos 3 secciones que interactuan dentro de una empresa, cada una la distribuiremos en organizaciones independientes, llamemoslas por ejemplo **GerenciaOrg**, **ContabilidadOrg**, **IngenieriaOrg**.

- **GerenciaOrg** serán los directivos de nuestra empresa. Ellos querran estar al tanto de todo y tener control total sobre los otros dos departamentos
- **ContabilidadOrg** podrá interactuar solamente mediante ciertas funciones de escritura que utilizaran para registrar pagos y costes de la compañia
- **IngenieriaOrg** solo tendrá control para registrar los proyectos que estan realizando y consultar datos de contabilidad.

**HACER DIAGRAMA EXPLICATIVO QUEDARIA MUY BIEN, SINO BORRAR TODO ESTO**

**ContabilidadOrg y IngenieriaOrg** tendrán su cada una su propio canal y unicamente podrán transaccionar con el, sin embargo **GerenciaOrg** tendrá la capacidad de leer y escribir en ambos canales ya que hemos definido nuestra politica de validacion de esta manera.

Esto permite mucha versatilidad a la hora de establecer reglas dentro de nuestra logica de negocio, permitiendonos tener un control total sobre quien o quienes pueden participar y ver datos.

-----------

###### Contrato inteligente y funciones implementadas dentro de la blockchain

Nuestro contrato inteligente o **chaincode**, esta desarrollado teniendo en cuenta las simples funcionalidades de nuestra aplicacion. He utilizado una metodologia de diseño basada en las bases de datos y sistemas de gestion de informacion denominada CRUD (Crete, Read, Update and Delete). 

El **chaincode** ha sido escrito en **JavaScript** valiendonos de la versatilidad, sencillez y grandes capacidades de este lenguaje. He seguido un estilo de programacion basado funciones (functional) para implementar las funciones del contrato.

Dentro del contrato, debemos definir la estructura de datos que seguira nuestra aplicacion para que pueda ser llamada mediante una API y ejecutar las funciones del **chaincode** desde el lado del cliente. Para ello, he optado por utilizar un objeto **User**,  que guarda un par clave-valor. Se utilizan como clave el `ID` del **User** y como valor la representación en cadena del objeto JSON. Cada entrada en el ledger se almacena con una clave única, en este caso los **ID'S DE LOS USUARIOS** y su correspondiente valor, el objeto JSON con toda la informacion de cada usuario.
![[Pasted image 20231122200450.png]]

![[Pasted image 20231123175737.png]]


En Hyperledger Fabric hay que diferenciar 2 tipos de funciones de la API de desarrollo que se utilizan para escribir o leer en el ledger. Una de ellas es **getState**. Esta funcion dentro del API de Fabric, consulta un par clave-valor indicado. Es una funcion muy rapida y no consume bloques. Es una simple consulta al world state que busca por la clave que introduzcamos como parametro.

Sin embargo, si queremos registrar algun dato debemos escribir en la red, ya sea para registrar nuevos usuarios o modificar informacion existente. Esto se realiza mediante el metodo **putState**. Esto genera un nuevo bloque (una transaccion) cada vez que lo llamamos. Es mucho mas lento que **getState**. Con esta funcion tambien podemos unicamente consultar informacion, pero estariamos escribriendo esa solicitud de lectura en la blockchain, relentizando mucho nuestra consulta. Hay que pensar en el uso de una u otra dependiendo de que funcion que queramos implementar.   

Para nuestro chaincode en concreto se han propuesto 7 funciones en total destinadas a interactuar con la red. Los nombres de las fuciones han sido asignados lo suficientemente explicativos para que el usuario pueda deducir su cometido sin necesidad de conocer programación. 
Vamos a enumerlas y explicar el porque de su eleccion.

- **createUser**:  Esta funcion es la encargada de registrar un nuevo usuario con un **ID** dado en la red. Todas las demas funciones tienen como argumento el ID del usuario al cual ser refieren. 

![[Pasted image 20231123182534.png]]
- **addTrip**: Como indica su nombre, añade un identificador de viaje, el origen y el destino y inicializa un objeto **bags**, para añadir posteriormente maletas si se desea. Tiene como argumentos id del usuario,  id del vuelo, origen y destino.
![[Pasted image 20231123182545.png]]
- **addBagToTrip**: Añade maletas a un viaje existente de un usuario existente. Aqui además inicializamos otro objeto **checkpoint** para cada maleta añadida. Este objeto tiene 3 argumentos (stage1, stage2 y stage3) de tipo bool que serán true cuando pasen satisfactoriamente los checks. En la inicializacion se establen a false.

![[Pasted image 20231123182559.png]]

- **addSizeAndPrice**: Funcion que toma como argumentos el id del usuario, id del viaje, el id de la maleta que estamos pesando, el peso que llega desde la aplicacion y el precio que se genera dependiendo de cuan pesada sea la maleta. Con esto registramos en la maleta concreta del usuario los datos de peso y precio.

![[Pasted image 20231123182610.png]]
- **addCheckPointsToBag**: Si nuestra maleta pasa por delante de un sensor y detecta que los datos de entrada son correctos, escribe **True** en la etapa del proceso que se encuentra y le añade una marca de tiempo. Esta marca de tiempo se genera  dentro de la funcion del **chaincode**.
![[Pasted image 20231123182625.png]]
- **readAsset**: Cuando se aporta un Id de usuario, devuelve todos los existentes relacionados con su clave-valor. Esta funcion se utiliza para consultar informacion del usuario. En la dApp se discrimina que funcion visualizar y representar.
![[Pasted image 20231123182632.png]]
- **deleteFlight**: Funcion que elimina un viaje por completo. Solo accesible desde el CLI. No está implementada a nivel de usuario.
![[Pasted image 20231123182647.png]]



Si nos fijamos, todas las funciones tienen un parametro denominado **ctx**. El **ctx** significa en este caso "contexto". Este "contexto" proporciona acceso al ledger de la blockchain dandonos informacion de la red y proporciona un objeto stub "ctx.stub" que posibilita el uso de API's para interactuar, como son los metodos **putState** y **getState** (entre otros muchos) ya mencionados anteriormente. 

Otro elemento comun en todas las funciones que podemos destacar es que estas funciones son de tipo **async**. Las funciones del tipo **async** se utilizan debido a que dentro de las redes blockchains la lectura o escritura de datos en el ledger, la realización de consultas a bases de datos externas de otras aplicaciones o canales, o la espera de confirmaciones de transacciones son totalmente aleatorias. Estas operaciones no se completan instantáneamente y requieren esperar una respuesta. Las funciones `async` permiten manejar estas operaciones de forma más eficiente y natural y ademas puediendo utilizar bloques try/catch para un mejor manejo de errores.

Toda la informacion adicional de estas funciones y el codigo completo, esta recogido en el **ANEXO III** del documento.

#### El ESP32 para la recopilacion de datos utilizando diferentes sensores.

https://www.circuitschools.com/what-is-esp32-how-it-works-and-what-you-can-do-with-esp32/

**Que mas incluir, consejos**

Se ha optado en el presente trabajo de utilizar el microcontrolador Xtensa Dual-Core 32-bit, aunque denominado comunmente como ESP32 de la familia de controladores de Espressif System. Estos chips destacan por su versatilidad y potencia, siendo ideal para aplicaciones en Internet de las Cosas (IoT). Integran capacidades WiFi y Bluetooth y admiten una variedad de funciones periféricas como ADC, DAC, UART, I2C, y SPI. Otra caracteristca que los hace ideales para sistemas IoT es su bajo consumo, pudiendo estar encendidos durante dias.

Las caracteristicas principales por las que se decidió por su utilización han sido:
- la capacidad de transmitir información via Wi-FI y la capacidad de utilizarse como servidor HTTP.
- multiples interfaces perifericas.
- el bajo coste del dispositivo.
- la sencillez de programación y documentación disponible en internet.
- alta disponibilidad de pines GPIO

Aqui tenemos el diagrama de la arquitectura que posee nuestro microcontrolador ESP32:
![[Pasted image 20231123190653.png]]

Dentro de todos los modulos que posee, se utilizaremos la **UART** para flashear la memoria RAM con los programas diseñados para el sensor de peso y la camará web, el **modulo Wi-Fi** para transmitir los datos de los sensores via HTTP hacia los nodos, el modulo **I2C** para la utilizacion de la camara que actuará como lector de codigos QR y el modulo **ADC** para la galga que medirá el peso.

La programacíon del dispositivo se ha realizado mediante el entorno de desarrollo de Arduino.


###### Implementacion de la cámara OV2640

La módulo de la camara OV2640 se implementó utilizando librerias propias de Arduino y de Espressif (empresa desarrolladora de la familia de microcontroladores ESP32) escritas y compiladas en el lenguaje Arduino.

La camara utiliza el protocolo I2C para comunicarse con el microcontrolador y esta conectada a los siguientes pines del micro:
![[Pasted image 20231128180906.png]]

No tenemos que preocuparnos por la disponibilidad de los pines, ya que el único uso que recibirán en los microcontroladores habilitados será la conexión con cámara.

Esta camara es capaz de captar imagenes de una resolución de 1632x1220 pixeles (UXGA) y una velocidad de conversion del ADC que lleva incorporado de 20MHz. Para nuestro proposito no será necesaria tal resolucíon de imagen, ya esta sobrecarga bastante al microcontrolador y lo que buscamos es una conexión fluida entre él y nuestro nodo servidor.

Para transmitir las imagenes que capta, el microcontrolador hace de servidor web HTTP mediante una libreria que proporciona Arduino,  denomiada **WiFi.h**. 
El programa esta diseñado para que cuando hagamos una solicitud a la direccion IP del microcontrolador (por ejemplo será 192.168.1.30 si estamos en un entorno local) junto con el añadido en la direccion de **/cam-hi.jpg**. Cuando accedemos a esta dirección estamos indicando que tome una foto y nos la envie a la respuestá, en este caso, un frame captado por la cámara. (El codigo completo y la configuracion está localizado en el **ANEXO V**)

![[Pasted image 20231128184537.png]]

**Proceso de la toma de imagenes**

Este procedimiento mencionado unicamente generá un frame por solicitud, por lo que tenemos que anidar muchas solicitudes para que estémos constantemete recibiendo imagenes, de esta forma conseguiremos reproducir un "video" y ser capaces de leer cada frame de ese video entrante, decodificando la imagen y tratando de averiguar si estamos leyendo un codigo QR correcto, un codigo QR falso o directamente que no esté presente ningun codigo QR para la lectura.

Por lo que, cuando ya somos capaces de coseguir captar imagenes con la camará, vamos a ver como anidamos la solicitud de captura y como mediante Python, somos capaces de leer codigos QR.

Me he ayudado de las siguientes librerias: 
- **request** para las solicitudes al servidor HTTP del ESP32
- **pyzbar** junto con **numpy** para la lectura y procesamiento de los codigos QR
- **cv2 (openCV)** junto con **numpy** para decodificacion de la imagen. 

El funcionamiento es sencillo. Debemos conocer de primera mano la direccion IP de nuestro microcontrolador para conectarnos a el, luego comenzamos con un bucle infito que hará de script permante. La solicitud, la realizamos dentro de un bloque **try/catch**. 
Aqui es donde se hace una peticion a la direccion del microcontrolador junto con "/cam-hi.jpg" para recibir la imagen, esta imagen se transforma a un array de bits y se decodifica ese array en un **frame**. 
![[Pasted image 20231128185530.png]]

Y mediante esta simple funcion de la libreria **pyzbar**: 
![[Pasted image 20231128191602.png]]

Somos capaces de detectar patrones en la imagen decodificada que pueden ser potenciales codigos QR para su lectura, devolviendo los datos que lleva asigando el codigo. Posteriormente veremos como estos datos serán introducidos en la **blockchain** utilizando nuesta dApp, aunque primero deberemos entender el concepto de **aplicacion descentralizada** y entender el funcionamiento del **gateway de Fabric**. Volveremos a este script en el siguiente capitulo para ver como se envian los datos decodificados a la **dApp**.

Con este programa somos capaces de:

- Configurar correctamente la camara y ser capaces de capturar imagenes.
- Ejecutar una peticiones de captura de imagen a nuestro microcontrolador y enviar la imagen al cliente que la solicita.
- Recibir la imagen, detectar si existen codigos QR y decodificar su información.
- Enviar estos datos a nuestra blockchain.

###### Uso de la galga y envio de información

Una celda de carga o galga es un transductor que convierte la fuerza que aplicamos sobre el a una señal electrica medible. La fuerza que aplicamos deforma el material y esta crea diferencias en su resistencia electrica.

Esto se consigue utilizando el principio del puente de Wheastone. El puente de Wheastone es un circuito con 4 resistencias con una rama central en medio por la 
que se pretende que no pase corriente electrica.


![[Pasted image 20231128193414.png]]




R2/R1​=Rx/R3​, donde R1, R2, R3, y Rx son las resistencias en el puente.

Si las resistencias conocidas son R1 y R2 (punto D) tienen la misma relación que las resistencias del lado B, la tension entre ambos puntos será 0 y no circulará corriente. Por el contrario, si existen diferencias se generará una diferencia de potencial y se comenzara a generar una corriente electrica.

En nuestro caso hemos utilizado una celula de carga común (hasta 20kg) que lleva incorporado un ADC de 24bits, el denominado HX711. Este ADC amplifica digitalmente la señal detectada en la celula de carga y es recibida en el microncontrolador. 
![[Pasted image 20231130180610.png]]

**(Figura del amplificador A/D HX711)**

Hay que realizar una fase de calibración previa para ajustar linearmente como se comporta la celula. Para ello, se coloca un peso conocido y se mide el resultado obtenido. Personalmente, hice varias mediciones con pesos conocidos y obtuve un coeficiente por el debia multiplicar la medida que obtenia de la galga para ajustar el peso. 

El **valor en bruto** se consigió utilizando una libreria existente capaz de interactuar con nuestro convertidor ADC `<HX711_ADC.h>` y el siguiente codigo:
```cpp 
#include <HX711_ADC.h>

const int HX711_dout = 4;
const int HX711_sck = 5;
HX711_ADC LoadCell(HX711_dout, HX711_sck);

void setup() {
  Serial.begin(115200);
  LoadCell.begin();
  LoadCell.start(2000); 
}

void loop() {
  LoadCell.update();
  long rawValue = LoadCell.getData();
  Serial.print("Valor en bruto: ");
  Serial.println(rawValue);
  delay(1000);
}
```

Se configuran los pines donde va conectado el convertidor, se inicializa el puerto serie para hacer debbugin de los datos y la celda de medida en la funcion **void setup()** y en el loop principal del programa se llama a la funcion **LoadCell.update()** para recibir el valor en bruto que nos devuelve el convertidor. Mediante esta sencilla formula obtenemos el factor de conversion teniendo un peso conocido:

![[Pasted image 20231130180937.png]]


Despues de obtener el factor de conversion, y por tanto nuestra celda de carga calibrada, debemos hacer que capture los pesos y los envie a nuestro nodo servidor. Para ello nos valdremos otra vez de la libreria <Wifi.h> de Arduino para crear un servidor HTTP y usaremos el mismo metodo que hemos seguido para enviar los frames capturados de la camara, aunque algo diferente, ya que queremos que siempre nos esté enviando el peso y no necesitaremos especificar como con la camara, una peticion en especifico, lo configuraremos de forma de que unicamente reciba peticiones **GET** y que cada vez que reciba una solicitud a la raiz **"/"** nos responda con la función **"handelRoot"** que es la encargada de hacer el envio.

```cpp
 // Inicializa el HX711
  LoadCell.begin();
  LoadCell.start(2000);
  LoadCell.setCalFactor(66.875);
  
  server.on("/", HTTP_GET, handleRoot);

 //continua el codigo...
```

```cpp
void handleRoot() {
  float peso = LoadCell.getData();
  server.send(200, "text/plain", String(peso));
}
```

Con esto obtendremos el peso cada vez que realizemos una solicitud del tipo GET hacia ``http://{ip del dispositivo}/``

Ahora nos queda obtener estos datos en el nodo, recordemos que este codigo va compilado y programado en el microcontrolador. Para la obtencion de los datos mediante solicitudes HTTP, volveremos a utilizar un script escrito en Python que utilizará la libreria **requests** para realizar las peticiones.

El script se compone de 4 funciones y un loop principal (el codigo de esta funciones se localiza en el **ANEXO V** del documento):

- **enviar_datos_al_backend** : Captura el valor del peso_real y lo envia a nuestro nodo servidor.
- **obtener_peso**: Envia una solicitud para obtener el peso **al microcontrolador**. Este le devuelve el peso medido. 
- **es_peso_estable:** Como estamos constantemente recibiendo mediciones, guardamos las 10 ultimas lecturas y hacemos una media, si esa media no varia en una franja de 100g, la damos por valida y se considera un peso estable.
- **monitorear_peso**: Esta funcion se encarga de meter en una cola de 10 elementos todos los valores que llegan atraves de obtener peso. Cuando se completa la cola utilizamos **es_peso_estable** para ver si esas 10 medidas la media no sobrepasan que cada una este fuera del rango de mas menos 100g, si es asi, devolvemos la media y comprobamos que no exceda el peso maximo establecido (20kg).
![[Pasted image 20231130190046.png]]

- El loop principal consiste en llamar constantemente a **monitorear_peso** y **enviar_datos_al_backend**. Si obtenemos una respuesta del backend correcta, imprimimos por consola el mensaje (ya sea correcto o erroneo).
```python
while True:
	peso_real = monitorear_peso(valor_maximo)
	respuesta = enviar_datos_al_backend(peso_real)
	if respuesta:
		print(f"El peso verdadero es: {peso_real:.2f} g")
		print(respuesta)
```



Con esto, tendriamos acaba la parte del sensor, tanto la recepcion de los datos como el envio al nodo servidor del peso.


### Desarrollo de la dApp e interconexion mediante la Gateway de Hyperledger Fabric

En este apartado veremos como se ha definido y desarrollado la parte de la aplicacion del cliente y como está recibe y envia datos mediante una **gateway** que hace de pasarella (una de sus traducciones literales del ingles) entre la blockchain y nuestra dApp.

Comenzaremos definiendo que una dApp, en esencia, realiza las mismas fucniones que cualquier aplicación que conozcamos, la diferencia está en el como. 
Una aplicacion descentralizada, ejecuta su codigo en la **blockchain.** En nuestro caso particular en Fabric, nuestro chaincode es parte de esta dApp que ejecutamos, donde el codigo está compilado e instalado dentro de un **peer** donde se ejecuta y pertenece a nuestra blockchain. La base de datos y las transacciones (operaciones, solicitudes en este caso), quedan alojadas de forma descentralizada como ya hemos visto, esto hace que las dApps, no dependan de un unico servidor donde están instaladas, mientras la blockchain a la que queramos acceder esté operativa, podremos seguir usandola y accediendo a los datos que nos ofrece. 

Cabe decir, que no todo está descentralizado. Tanto el frontend (la que vemos en una página web) como el backend de nuestra aplicacion, estan alojados en un servidor de Nodejs el cual se conecta a nuestra blockchain (nuestra aplicacion, dApp) mediante un **gateway de Hyperledger Fabirc**.

El **Fabric Gateway** no es mas que una API que nos proporciona una forma conectarnos externamente a nuestra **blockchain**, posibilitando que podamos (teniendo las credenciales necesarias) interactuar con la red.
![[Pasted image 20231209185857.png]]
Cuando explicamos las funciones que tenian nuestros smartcontracts, la forma de ejecutar las funciones que estaban instaladas era unicamente **ejecutandolos desde el mismo nodo, mediante la linea de comandos (CLI).** Esto es muy problematico a la hora de desarrollar cualquier tipo de aplicación, nos seria imposible que un usuario externo tuviese que escribir cada vez que quiera realizar un **registro de usuario**, todos los parametros y argumentos necesarios ademas de que tendria que tener una conexión directa al peer en cuestión.

Con **Fabric Gateway** se simplifica todo. Gracias a esta API, somos capazes (previa autentificacion con credenciales) de acceder a nuestro peer y ejecutar las operaciones de nuestra dApp sin necesidad de tener un acceso completo a nuestro nodo.
Cualquier funcion que realize el usuario desde la dApp, seguira esta cadena de interaccion de los diferentes componentes que utiliza la aplicacion.
![[Pasted image 20231209185748.png]]


###### Funcionamiento de nuestra dApp

Los directorios y la organizacion de nuestra dApp esta distribuida de la siguiente forma:
![[Pasted image 20231210211721.png]]
- La caperta **src**, tenemos nuestro archivo principal **main.ts** que es el encargado de llamar a **gatewaylogin.ts** y **chaincode.ts** para la autentificacion del gateway y para utilizar la API del **chaincode** que hemos instalado. Denominaremos a esta carpeta como nuestro backend, ya que aqui es donde se efectua el procesamiento de datos entre nuestro servidor y blockchain.

- Dentro de **public**, tenemos nuestro frontend. Esta la estructura de la pagina web (dApp) en **index.html** junto con **styles.css**. Los archivos de Javascript incluyen funciones que hacen posible la llamada a la nuestro backend para mostrar busquedas de usuario o enviar la informacion que los clientes escriban en pantalla.



La aplicacion tiene diferentes funciones, **registrar nuevos usuarios, añadir nuevos viajes con las respectivas maletas que se utiizaran, pesar la maleta y conseguir el precio de facturación y un buscador para ver un historial de todos nuestros viajes.** Todas estas funciones  transfieren informacion entre distintos los componentes que en conjunto determinan nuestra dApp. 

![[Pasted image 20231210200204.png]]


Ya hemos definido con anterioridad las funciones que realiza nuestro **chaincode**. Estas funciones son utilizadas por nuestra aplicación para dar sentido al proceso realizamos, como por ejemplo, para registrar usuarios utilizamos **createUser**, para registrar un vuelo, se ven involucradas las funciones del chaincode, **addTrip y addBagToTrip**. 

La **Fabric Gateway** como ya comentamos, es una pasarela entre nuestro backend y la blockchain. Para ejecutar todas las funciones, debemos tener las credenciales e identidades correctas dependiendo de que red blockchain queramos conectarnos. En nuestro caso, debemos incluir datos como **la identidad de la organización a la que pertenece nuestro usuario, sus certificados cliente y clave privada y credenciales TLS**. ![[Pasted image 20231210203419.png]]
Si la conexión se establece de forma satisfactoria, esta funcion nos devuelve dos objetos del tipo **network** y **contract** que tienen las propiedades necesarias para poder establecer conexión con nuestra blockchain. Estos valores son leidos en nuestro programa principal, donde cuyos argumentos son los necesarios para interactuar con nuestro **chaincode**. Incluyen informacíon del contrato al que queremos utilizar y de la red a la que queremos conectarnos. Esta verificación de credenciales es **vital**, sin ella no se podria interactuar con la **blockchain** desde una aplicación externa. 

Además de estas funciones que son activadas por el usuario de forma manual, tenemos otras funciones que son registradas de forma automatica, como es la **información de los sensores provenientes del ESP32**. Esta información es leida a petición cuando nuestro microcontrolador mediante el script de Python desarrollado, envia los datos que se han registrado (lectura de los identificadores QR y peso de cada maleta medido mediante la celda de carga). Estos datos se procesan internamente mediante la función de nuestro chaincode **addCheckpointToBag**, donde queda registrado que sensor y que etapa ha sido completada con éxito.


#### Diseño del buscador y funciones de la dApp

Esta es la apariencia actual (incluida en los ANEXOS) que tiene la dApp en nuestro navegador:

![[Pasted image 20231210193130.png]]

Es una simple pagina escrita en **HTLM** y **JavaScript** como frontend, donde el usuario puede realizar todas las funciones disponibles descritas con anterioridad.

Ahora vamos a describir las actividades que la aplicacion puede realizar:

- **Registrar nuevo usuario**: El usuario se registra dentro nuestra blockchain, con un alias o nombre que el decida. Si ya existe ese nombre, se le pide que por favor, introduzca un nombre que este disponible. Para ejecutar cualquier otra funcion en la aplicacion, es necesario tener un **ID**.
- **Añadir Viaje Completo:** Incluyendo el ID del usuario, se introduce de forma manual el Origen y Destino que marca en su billete o tarjeta de embarque. Además si lleva maleta, debe añadir la maleta o maletas que realizará el seguimiento. Cuando esto ocurre, se generan codigos QR's asociados a su maleta que deberá imprimir y adherirlos a sus maletas para seguir con el proceso. ![[Pasted image 20231210205744.png]]
- **Confirmar peso y precio maleta**: Aqui el usuario debera introducir su ID, el identificador asignado a su viaje y el identificador de la maleta que esta facturando. Esto lo obtendra utilizando el buscador, ya que se genera de forma dinamica. Esta funcion al completarse, valida la etapa de **registro de facturacion**.![[Pasted image 20231210210015.png]]
- **Buscar**: Utilizado para ver el historial del usuario y toda la informacion relevante a las maletas, destinos y registros de trazabilidad.
 ![[Pasted image 20231210210220.png]]


Estas son las funciones que un usuario puede realizar, aunque quedan por describir las **funciones de registro que se realizan cuando los microcontroladores envian informacion correcta a los nodos**. Estas funciones se ejecutan de forma automatica cuando nuestros sensores detectan que la maleta registrada ha pasado correctamente por el lector de QR's que se ejecutan en el backend de nuestro servidor Nodejs.

#### Funciones del lado del servidor

Recordemos que para la recepción de los datos provenientes de los microcontroladores, utilizamos 2 scripts en Python (ya mencionados) que solicitan la información al propio servidor http del microcontrolador, obtienen los datos y estos se envían mediante una solicitud HTTP a nuestro backend que posteriormente los procesa. Este seria el ciclo de trabajo de envio y recepción de los datos del microcontrolador con nuestra aplicación.

El backend está programado utilizando el framework de Express que nos ayuda a fácilmente crear solicitudes HTTP del tipo (get / post) para obtener datos de los diferentes endpoints que hemos programado. Tendriamos este sencillo ejemplo donde:
```javascript
const express = require("express");
const app = express();
const port = 3000;

//Esta seria nuestra solicitud donde estariamos enviado a nuestro endpoint {ip}/ el mensaje "Hello World!"
app.get("/", function (req, res) {
  res.send("Hello World!");
});
//Esta linea es para indicar donde nuestra aplicacion escuchara las solicitudes que le hagamos, hay que referenciar un puerto concreto, en este caso el 3000.
app.listen(port, function () {
  console.log(`Example app listening on port ${port}!`);
});

```

Visto esto, el procedimiento de crear solicitudes HTTP es simple. Vamos a ver ahora el codigo desarrollado para procesar las solicitudes de nuestra camara:
![[Pasted image 20240121121411.png]]

En este fragmento de código, recibimos los datos que son enviados por nuestro script de Python y los procesamos. En nuestro script, hemos creado un objeto JSON con dos atributos donde almacenamos la información de la captura realizada por el microncontrolador. Una de esas partes la denominamos IDENTIFICACION, aquí es donde almacenamos lo que tenemos escrito en nuestro QR, que no es mas que 3 lineas en texto plano con esta estructura:

* userID:
* tripID:
* bagID:

Para que podamos identificar una maleta necesitamos el ID del usuario, el ID del vuelo para saber que trayecto es y el ID de la maleta registrada. Si y solo si, nuestra función leerá un código QR’s que tenga esa misma estructura, cualquier otro código será rechazado, saldrá de la función y no activará por tanto la función de registro. Recordemos que este código QR se genera automáticamente en la web utilizando una API a un servicio que genera dichos QR’s. De igual manera, se podría generar el código QR de cualquier forma que se desee pero deberá seguir la misma estructura mencionada.
![[Pasted image 20240121121757.png]]
Se hace una verificación previa del tipo de dato comprobando si es un Array para el procesamiento y también se comprueba si tene una longitud de 3 saltos de lineas, de ser así, se continua con el proceso.

Para leer las propiedades del atributo INDENTIFICACION al venir en un string con salto de lineas, se itera cada salto de línea, separando la primera parte y la segunda.

Luego, teniedno ya separadas cada linea, leemos **key** iterando el string guardandolos en una variable **item** que es una **String**. Despues la variable **parts** separa por los elementos del string cuando aparecen "**:**". La primera parte sera nuestra **clave** para identificar el atributo, en este caso podra ser **userID**, **tripID** o **bagID**, y la otra parte del **string** sera el valor, en este caso, el id del viaje, de la maleta o del vuelo.

Posteriormente, volvemos a leer el otro atributo de nuestro objeto JSON, denominado esp32unit. Este tiene un único valor, dependiendo de si se recibió información desde el sensor numero 1 o numero 3. Esto se define en el script de Python donde se incluye desde el microcontrolador que se envia la información.

Cuando obtenemos este valor, ya tenemos todos los identificadores necesarios para verificar nuestra maleta: ID del usuario, ID del viaje, ID de la maleta y numero identificativo de la etapa donde se encuentra, en este caso, dada por el ESP32 que envia los datos.
![[Pasted image 20240121122542.png]]

Con esto, ejecutaríamos nuestra función de addCheckpointToBag con todos los argumentos necesarios (son todos los datos obtenidos) y escribiríamos en nuestra blockchain la información de que la maleta ha sido registrada bajo todos estos parámetros, completándose así los checks de llegada a los aeropuertos.


De esta forma, quedaria finalizada la presentación de todas las funcionalidades, transmisión de información entre componentes y servicios utilizados en nuestra aplicación, quedado el comportamiento y uso totalmente definido.


-----------------

### Conclusiones

Comenzaré haciendo una primera mención a lo mucho que he disfrutado realizando este TFG. Gracias a él, he ampliado de forma considerable mis conocimientos sobre programación, arquitectura del software y blockchain, ayudandome a estar preparado frente a los nuevos desafíos tecnológicos fuera de mi ámbito (la electrónica) que seguramente nos acontezcan en años venideros.

Dejando a un lado esta pequeña reflexión/opinión personal, vamos a centrarnos en los resultados y objetivos conseguidos en relación a nuestro objeto de estudio.

En este presente trabajo, se ha demostrado que es posible la creación de una red blockchain que realiza un trabajo de trazabilidad utilizando dispositivos IoT de bajo coste. Para ello se diseñó, creo y se puso en funcionamiento satisfactoriamente una red basada en Hyperledger Fabric que cumpliese las características necesarias para nuestro objeto de estudio. Después, se diseño un caso de uso utilizando smartcontracts que utilizaríamos para realizar la función de tracking valiéndonos una aplicación web junto con dispositivos IoT.

Aunque no nos haya sido posible realizar un testeo exhaustivo de las funciones programadas, como la velocidad de transacción (tx/s) y la de calidad de las transmisiones de datos entre los diferentes componentes de la arquitectura propuesta en concreto (IoT, aplicación web y blockchain), podemos sacar datos significativos con varias pruebas realizadas. Comenzemos con los dispositivos IoT.

Los dispositivos IoT, microcontroladores ESP32, como ya se mencionó en el apartado X, son mas que suficientes para la captación de imágenes y transmisión/procesamiento de los datos de peso proporcionados por la galga, el problema de rendimiento viene dado porque también están configurados para poder enviar y recibir peticiones HTTP, por lo que tienen instalados además un  servicio de servidor web, y a la hora de realizar la transmisión de datos se ha detectado que la calidad de la transferencia no es buena.  En el mejor de los casos somos capaces de enviar aproximadamente 25-30 fotogramas por segundo.  Por el contrario en el peor de los casos, tenemos la imagen congelada por mas de 10 segundos.

Una solución posible seria instalar una antena wifi al microcontrolador para mejorar su cobertura además de facilitar un mejor acceso a la red wifi utilizada, y por supuesto, optimizar el código programado.

Para medir las velocidades de transacción (tx/s) de nuestra red basada en Hyperledger Fabric se han efectuado 1000 peticiones de lectura y 1000 peticiones de escritura. Hay que diferenciar estos 2 tipos de operaciones, siendo la escritura mucho más costosa en términos computacionales, por lo tanto, mucho más lenta. Para sacar una conclusión de los tiempos nos fijaremos en las velocidades de escritura, que son las que determinarán el peor escenario en nuestra red. Recalco que dependiendo del hardware que se utilicé en la prueba estas velocidades cambiaran.
Para obtener el hardware completo de la maquina en cuestion donde se han tomado estas medidas, he optado por la utilizacion en linux de la herramienta **hwinfo** donde nos hace un desglose exhaustivo del hardware del equipo. Algunos datos han sido omitidos ya que no aportan mucha informacion al respecto:

| Componente        | Modelo                                                   | 
|-------------------|----------------------------------------------------------| 
| **cpu:**           |                                                          | 
|                   | AMD Ryzen 5 2600 Six-Core Processor, 1560 MHz            | 
|                   | AMD Ryzen 5 2600 Six-Core Processor, 1550 MHz            | 
|                   | AMD Ryzen 5 2600 Six-Core Processor, 3890 MHz            | 
|                   | AMD Ryzen 5 2600 Six-Core Processor, 1559 MHz            | 
|                   | AMD Ryzen 5 2600 Six-Core Processor, 3900 MHz            | 
|                   | AMD Ryzen 5 2600 Six-Core Processor, 1559 MHz            | 
|                   | AMD Ryzen 5 2600 Six-Core Processor, 1559 MHz            | 
|                   | AMD Ryzen 5 2600 Six-Core Processor, 1560 MHz            | 
|                   | AMD Ryzen 5 2600 Six-Core Processor, 3900 MHz            | 
|                   | AMD Ryzen 5 2600 Six-Core Processor, 1559 MHz            | 
|                   | AMD Ryzen 5 2600 Six-Core Processor, 3900 MHz            | 
|                   | AMD Ryzen 5 2600 Six-Core Processor, 1558 MHz            | 
| **keyboard:**      |                                                          | 
| /dev/input/event12| SHARKOON USB-HID Gaming Keyboard                          | 
| /dev/input/event7 | Xenta 2.4G Wireless Device                                | 
| **mouse:**         |                                                          | 
| /dev/input/mice    | Razer Viper Mini                                         | 
| /dev/input/mice    | Xenta 2.4G Wireless Device                                | 
| **monitor:**       |                                                          | 
|                   | BenQ RL2455                                               | 
|                   | DELL G2724D                                               | 
| **graphics card:** |                                                          | 
|                   | ATI Navi 10 [Radeon RX 5600 OEM/5600 XT / 5700/5700 XT]  | 
| **sound:**         |                                                          | 
|                   | ATI Navi 10 HDMI Audio                                    | 
|                   | AMD Family 17h (Models 00h-0fh) HD Audio Controller      | 
|                   | Logitech G435 Wireless Gaming Headset                    | 
| **storage:**       |                                                          | 
|                   | KIOXIA Non-Volatile memory controller                    | 
|                   | AMD 400 Series Chipset SATA Controller                   | 
|                   | AMD FCH SATA Controller [AHCI mode]                      | 
| **network:**       |                                                          | 
| enp34s0           | Realtek RTL8111/8168/8411 PCI Express Gigabit Ethernet   | 
|                   | Controller                                               | 
| **network interface:** |                                                     | 
| lo                | Loopback network interface                               | 
| docker0           | Ethernet network interface                               | 
| enp34s0           | Ethernet network interface                               | 
| **disk:**         |                                                          | 
| /dev/nvme0n1      | KIOXIA Disk                                              | 
| /dev/sdb          | TOSHIBA DT01ACA1                                         | 
| /dev/sdc          | ST31000528AS                                             | 
| /dev/sda          | Samsung SSD 850                                          | 


Los tiempos de lectura y escritura se han medido realizando como he comentado dichas solicitudes a la red y recogiendo los datos que aportan las transacciones al ser finalizadas. Aqui podemos ver los datos que nos aportan las transacciones en el log del **peer**, en este caso con una operacion de escritura efectuada desde nuestro servidor Nodejs. Hay que tener en cuenta que la transaccion viaja desde el servidor Nodejs, utilizando el gateway de Fabric y ejecutando la funcion del smartcontract. Esta resaltado en verde la velocidad que ha tardado en ejecutar el codigo:

![[Pasted image 20240121123839.png]]


----------

Pues siguiendo esta metodologia, se han realizado 100 medidas en las mismas 
condiciones, realizando una media aritmetica de todas las medidas:



| Tipo de funcion (N) | Transaccion completada (ms) |
| ---: | ---: |
| Lectura  (100) | 73 |
| Escritura (100) | 212 |

Hay que tener en cuenta, que hay funciones dentro de nuestra aplicacion que pueden llamar a varias funciones, por lo que este tiempo se vera aumentado por el numero de funciones a las que se llame. 

La forma de optimizar esto seria haber programado directamente dentro del smartcontract una funciones mas complejas, ya que el tiempo de procesamiento es infimo en comparacion a los tiempos que se tarda en aprobar las transacciones en la red, optimizando mucho mas el proceso.

-----------

También, uno de los problemas hablados ha sido la redundancia de los datos. Esto en nuestra prueba de concepto no nos afectaba, ya que no tenemos una gran cantidad de datos, pero de la forma que tenemos configurada nuestra red y programados nuestros smartcontracts, hay que tener en cuenta que a medida que aumentamos la información relativa a un cliente, cuando utilizamos la función de lectura, llamamos al historial completo de ese cliente, con lo que, cuando este aumentase mucho, debido a la gran información almacenada seria cada vez mas costoso para la red.

-------------

Con los resultados obtenidos, podríamos decir que la prueba de concepto realizada ha sido un éxito, siendo totalmente viable la utilización de la tecnología blockchain enfocada al ámbito de la trazabilidad, a falta de mejorar ciertos componentes como puede ser el envio de datos de los microcontroladores para una mejor consistencia en la transmisión y la velocidad de transaccion y aprobacion de las solicitudes de la red para una mejor optimizacion del proceso en un entorno empresarial. Recordemos que el uso de blockchain también aporta mucha mayor seguridad, inmutabilidad de los datos y una mejor auditabilidad en los procesos de trazabilidad frente a una arquitectura basada en bases de datos convencionales. Esto claro está, con los inconvenientes que se tiene en invertir en una nueva infraestructura con mayor y mejores sistemas al aumentar masivamente la redundancia de información, cuestión a tener en cuenta para grandes cantidades de datos.

Para el sistema de nuestra prueba de concepto se optó por diseñarlo en “bare-metal” (sobre el metal, directamente en las maquinas) aunque actualmente se diseñan estas redes mediante el uso de maquinas virtuales e instancias en la nube como Amazon AWS o IBM Clouds, que ofrecen arquitecturas configurables y servidores ya prediseñados.

Me gustaria concluir con que cada vez existen más y más compañías tecnológicas que se suman al carro de la implementación de sistemas blockchain para sus servicios (ya sea Hyperledger Fabric, Hyperledger Besu, Corda, Etherum (Geth) … ) impulsando cada vez más esta tecnología que va abriéndose paso poco a poco en el mercado. Gracias a la ayuda de las criptomonedas y criptoactivos, también las grandes compañías financieras han puesto un ojo en estos servicios, dándoles mas visibilidad, proporcionando una mayor inversión y un desarrollo constante a largo plazo.

Espero en un cercano futuro poder participar en parte de esta transición tecnológica.



