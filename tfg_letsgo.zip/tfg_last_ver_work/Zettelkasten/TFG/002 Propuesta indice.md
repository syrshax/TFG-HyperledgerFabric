***1. Resumen keywords abstract keywords***
***2. Introduccion***
	1. Justificar el tema por la relevancia tecnologica (uso de blockchain), la escasez de investigacion y en aplicaciones concretas en este campo de industria y la interdisciplinariedad (hardware/software y otros ambitos)
	2. La necesidad de un sistema seguro, confiable, inmutable y por tanto auditable

***3. Estado del arte***
	**1. Organizacion-Gestion-Trazabilidad de equipaje y pasajeros en Aeropuertos**
		1. Breve historia de los aeropuertos y estos métodos
		2. Que es una "supply-chain", cadena de suministro
		3. Sistemas actuales de gestión
	**2. Blockchain (como gestión de datos - como rastreador inmutable)**
		1. Breve historia
		2. Bases de la criptografia y consenso.
		3. Lógica, los smart contracts
		4. Hyperledger Fabric
	**3. Dispositivos IoT, tecnologias, historia**
		1. Industria 4.0, relevancia dispositivos IoT.
		2. Modos de comunicacion
	
***4. Metodologia y estructura de trabajo seguida:**:***
 1. Una blockchain basada en Hyperledger Fabric
 2. Arquitectura del sistema
 3. **Configuracion de una red blockchain escalable utilizando Hyperledger Fabric**
		1. Configuraciones previas
			1. Creacion identidad con cryptogen
			2. Configuracion de los peers
			3. Configuracion del orderer
			4. Configuracion del bloque genesis
		3. Creacion del canal uniendo todos los elementos
			1. Seleccion del Anchor-Peer
				1. Que es
			2. Union de los demás peers a un canal existente. La escalabilidad.
3. **Implementación de Smart Contracts y Adquisición de Datos mediante IoT (ESP32)**
		1. Diagramas de transmision de informacion
		2. El ESP32 para la recopilacion de datos utilizando diferentes sensores:
			1. Camara OV2460
			2. Galga
		3. Funciones necesarias a implementar en el smart contract
		4. Empaquetamiento e instalacion del smart contract en los nodos
		5. Comprobacion del correcto funcionamiento
4. **Implementacion e Interconexion del Gateway la Dapp**
		1. Que es el Fabic Gateway y su funcionamiento.
			1. Wallets y usuarios 
			2. Login, credenciales
		2. Desarrollo del backend y envio de datos del ESP32 a la blockchain
		3. Creación de un frontend y utlimando detalles para el usuario final
***5. Hipotesis / Objetivos a conseguir:**
	1. planteamiento
	2. recopilar fuentes y datos
	3. herramientas utilizadas
	4. como ha sido la ejecucion del proyecto
	5. análisis de los resultados
	6. si cumple o no el objetivo y sus limitaciones

***6. Resultados, puesta en marcha, benchmark utilizando Hyperledger Caliper (?)***

***7. Conclusiones***
***8. Bibliografia***
***9. Anexo***
