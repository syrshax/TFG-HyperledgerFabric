En el año 2008, apareció la primera aplicación de la tecnologia blockchain, a muchos les sonará el nombre de Bitcoin. Esta fue desarollada por un enigmatico Satoshi Nakamoto el cual adquirio este nombre como un pseudonimo y cuya identidad sigue todavia en paradero desconocido.

La blockchain de Bitcoin, fue la primera aplicaci´on real a la que fue sometida la esta tecnologia a ojos de un público mas general y no solo en entornos de desarollo. Estaba destinada particularmente un ambito dentro de las finanzas, que hoy dia conocemos como "criptomonedas" o cripto activos. 
Para sus desarolladores Bitcoin tenia el proposito de ser una alternativa a los bancos tradicionales para dejar de depender de estos como intermediaros y de asegurarle al usuario que el activo financiero, este caso los Bitcoins, eran suyos ya que una de las ventajas de esta tecnologia es proporcionar soberania a cada usuario sobre la custodia de sus activos.

Para las transacciones, Bitcoin se basa en que unicamente necesitas una marca criptografica identificativa  (se basa en una combinación de claves publico - privadas) en lugar de tener que depositar la confianza en un tercero para realizar transacciones (en este caso el tercero puede ser cualquier intermediaro, un banco por ejemplo). 

Estas transacciones debido a su carga criptografica son actualmente *(referencia buscar)* computacionalmente imposibles de modificar, esto genera una gran proteccion
a los vendedores de posibles fraudes que puedan sufrir, y si ademas aplicamos mecanismos de custiodia (proporcionados por un tercero, ya que la propia tecnologia Bitcoin en sí no los posee) tambien otorga a los compradores seguridad, pudiendo por tanto proteger sus Bitcoins de recibir cualquier tipo de ataque malicioso.

Bitcoin se encontro con algunos problemas en su desarrollo, uno de ellos fue el problema del ”doble gasto". En concreto trataba de como solventar el problema de que una moneda pudiese ser utilizada varias veces en una misma transacción pudiendo ser copiada. 
Para ilustrarnos tengamos como ejemplo:

"Imaginemos que Alice tiene 1 bitcoin y quiere comprar dos artículos diferentes de dos vendedores diferentes, Bob y Carol. Si Alice intenta enviar ese mismo bitcoin tanto a Bob como a Carol al mismo tiempo, estaría intentando hacer un doble gasto.

Solo una de esas transacciones (la que sea confirmada primero por la red) será aceptada y añadida a la blockchain. La otra transacción será rechazada.

Una vez que recibes bitcoins en tu **wallet** y se confirma la transacción, esos bitcoins son tuyos y puedes gastarlos como desees en futuras transacciones. La clave aquí es que una vez que una transacción ha sido confirmada, esos bitcoins específicos no pueden ser gastados dos veces en el mismo momento."
**(Bitcoin whitePapper)**


La solución propuesta para el problema del doble gasto en Bitcoin fue la implementación de un sistema donde todas las transacciones se registran en una cadena de bloques la ya muchas veces mencionada **blockchain**. Esta blockchain actúa como una base de datos descentralizada y distribuida en la que se almacenan todas las transacciones. (https://traders.studio/como-evita-una-cadena-de-bloques-el-doble-gasto-en-bitcoins/#:~:text=Este%20problema%20de%20%C2%ABdoble%20gasto%C2%BB,PoW)

Para asegurar y validar estas transacciones, se introduce la figura del 'minero'. Los mineros son nodos especializados en la red que participan en el proceso de prueba de trabajo, resolviendo desafíos criptográficos complejos para agregar nuevos bloques a la cadena. Una vez que un minero ha encontrado un bloque válido, este se añade a la blockchain y las transacciones contenidas en ese bloque se consideran confirmadas.

Como incentivo por este trabajo, los mineros reciben una recompensa en forma de bitcoins recién creados, así como las tarifas de las transacciones que han incluido en el bloque. Esta recompensa motiva a más participantes a unirse al proceso de minería, fortaleciendo la seguridad y estabilidad de la red. (https://academy.binance.com/es/articles/how-to-mine-bitcoin?ref=HDYAHEES)


# Fundamentos de la blockchain y base criptografica de funcionamiento

Con la terminología **blockchain** ya multiples veces definida, vamos a indagar un poco mas en su principio de funcionamiento y los elementos que la componen.

Comenzamos definiendo el primer bloque de la cadena, el cual es denominado **bloque genesis**. Este bloque sirve como punto de partida contiene las bases por las cuales se regiran los subsiguientes bloques. **(Reyna, A., Mart´ın, C., Chen, J., Soler, E., D´ıaz, M.: On blockchain and its integration with IoT. Challenges and opportunities. Futur. Gener. Comput. Syst. 88, 173–190 (2018))**. Él establece ciertas reglas y parametros basicos del sistema, como tipo de consenso, tamaño m´aximos de informaci´on que puede albergar cada bloque... Aunque esto depende del tipo de blockchain que se utilize, en nuestro caso en concreto de uso de Hyperledger Fabric, el bloque genesis nos permite todas estas configuraciones. (https://hyperledger-fabric.readthedocs.io/en/latest/configtx.html)

Cada bloque en una blockchain está identificado mediante un _hash_. Este **hash** se genera a partir de la información contenida en el bloque actual junto con el _hash_ del bloque anterior. Un _hash_ se puede definir como:

Una función HH que procesa una entrada finita de información arbitraria hacia una salida de longitud fija, referida como valor _hash_ (**Cryptographic Hash Functions**). En la práctica, la longitud de la salida es alrededor de 160 bits, y esta salida se denomina _hash criptográfico_.

Esta estructura permite verificar la integridad de todas las transacciones pasadas gracias a un _árbol de Merkle_. Un _árbol de Merkle_ organiza los _hashes_ de las transacciones en una estructura de árbol binario, donde cada nodo no terminal contiene el _hash_ de la concatenación de los _hashes_ de sus nodos hijos. Solo es necesario mantener el _hash raíz_ del árbol de Merkle, que es el _hash_ del nodo más alto, para verificar ciertos datos específicos. Este _hash raíz_ se incluye en el encabezado del bloque, y al comparar el _hash raíz_ almacenado con el _hash raíz_ calculado a partir de las transacciones presentes, se puede verificar que las transacciones no han sido alteradas y son correctas.


El nombre de *arbol de Merkle* viene dado despues de su creador
Ralph Merkle **(Ralph C. Merkle. A digital signature based on a
conven- tional encryption function. In Carl Pomerance, editor, Advances in Cryptology — CRYPTO ’87, pages 369–378, Berlin, Heidelberg, 1988. Springer Berlin Heidelberg.)** Estos arboles de Merkle calculan utilizando los pares de hashes de los subsiguientes bloques una suma total de todos los bloques combinados.

Esto nos permite comprobar si algún bloque ha sufrido alguna modificación sin la necesidad de verifcar todo el conjunto.
Como ya hemos comentado, el hash se genera con un conjunto de informacion que contiene el bloque, si esta informacion se ve alterada, el hash de salida, el *hash criptografico*, se vera modificado y el arbol de Merkle, su raiz, tambien se ver´a modificada. Con esto se comprueba la integridad de los datos de una forma mucho mas liviana en terminos de poder computacional que si tuviesemos que ir comprobando bloque a bloque.


Otra aspecto crucial de la _blockchain_ es la manera en que **se transmiten los datos a todos los nodos** y cómo **los nodos alcanzan un consenso sobre la validez de esa información**.

Cuando efectuamos una transacción dentro de la red blockchain, necesitamos proporcionar una clave criptográfica válida para autorizar dicha transacción. Uno de los métodos criptográficos utilizados es la Criptografía de Curva Elíptica (ECC, por sus siglas en inglés, de _Elliptic Curve Cryptography_). **(Elliptic Curve Cryptography and its Applications)**. 

Suponiendo que nuestra clave criptográfica sea aceptada por la red, la transacción mencionada se llevará a cabo. Una transacción se interpreta como una transferencia de datos entre dos usuarios, y necesita ser validada por los nodos en la red.

Para propagar y validar transacciones, se utiliza un _protocolo de inundación_ conocido como _Gossip Protocol_. Dependiendo de la configuración inicial de nuestra blockchain, ciertos nodos o todos los nodos, validarán la transacción. Este protocolo replica la información a los nodos configurados, y la validación de la transacción se logra a través del _consenso de la red_, según se describe en el libro _Bitcoin and Blockchain Security_ de Ghassan Karame y Elli Androulaki."


Esta cuesti´on del consenso, ya surgi´o hace tiempo en un termino militar,donde varios generales deciden atacar y otros prefieren defender.De ah´ı el nombre del Problema de los Generales Bizantinos. **(The Byzantine Generals Problem)** . El Problema Bizantino, formulado por Pease, Shostak y Lamport en 1982 es una cuesti´on central en la teor´ıade sistemas distribuidos y la ciencia de la computaci´on. Intenta alcanzar
un consenso en una red distribuida, especialmente cuando existen nodos malignos que pueden proporcionar una informaci´on falsa.**(A Survey on Byzantine Agreement Algorithms in Distributed Systems)**. El consenso en una red distribuida es uno de los conceptos base en la tecnologia blockchain. Este se definiria como el acuerdo que surge entre las varias partes de la red, ya que los nodos entre s´ı no pueden verificar su informaci´on con referencia a un nodo central, tienen que hacerlo entre
ellos.



El tema del consenso tiene sus raíces en un contexto militar antiguo, donde se presenta un escenario en el que varios generales deben decidir entre atacar o defender. Esta situación dio origen al nombre del _Problema de los Generales Bizantinos_ (**The Byzantine Generals Problem**). Este problema, formulado por Pease, Shostak y Lamport en 1982, se ha convertido en una cuestión central en la teoría de sistemas distribuidos y la ciencia de la computación, intentando alcanzar un consenso en una red distribuida, especialmente en presencia de nodos malignos que pueden proporcionar información falsa. (**A Survey on Byzantine Agreement Algorithms in Distributed Systems**).

El consenso en una red distribuida es un pilar fundamental en la tecnología blockchain. Se define como el acuerdo alcanzado entre las diversas partes de la red. Dado que los nodos no pueden verificar su información con referencia a un nodo central, deben hacerlo entre ellos. En la blockchain, resolver el Problema de los Generales Bizantinos permite asegurar que todos los nodos lleguen a un consenso sobre la validez de las transacciones y los bloques, incluso cuando existen nodos malintencionados en la red. Esta resolución del consenso es crucial para mantener la integridad y la seguridad de la red blockchain."

