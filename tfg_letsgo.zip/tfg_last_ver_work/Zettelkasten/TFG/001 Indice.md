# 1. Introduccion

# 2. Estado del arte
  ## 2.1 El sector aeronautica en la gestion y trazabilidad de mercancias y equipajes
   ### 2.1.1 Historia de la gestion y primeras etapas del sector aeronautico
   ### 2.1.2 Estructura y mecanismos actuales para la manipulación y estandares de mercancias
 ## 2.2 Blockchain como gestora de datos y tracker inmutable.
  ### 2.2.1 Los inicios de la tecnologia blockchain
  ### 2.2.2 Fundamentos de la blockchain y base criptografica de funcionamiento
  ### 2.2.3 Smart contracts
 ## 2.3 El entorno IoT y su aplicacion en blockchains
  ### 2.3.1 Los dispositivos IoT y metodos de transferencia de informacion
  ### 2.3.2 Las comunicaciones
  ### 2.3.3 La tecnologia blockchain en entornos IoT
# 3. Metodologia
 ## 3.1 Blockchain basada en Hyperledger Fabric
 ## 3.2 Arquitectura del sistema
 ## 3.3 Configuracion de una red blockchain escalable utilizando Hyperledger Fabric
  ### 3.3.1 Requerimientos previos
  ### 3.3.2 Creacion de identidades con material criptografico
  ### 3.3.3 Configuracion del bloque genesis
  ### 3.3.4 Configuracion de los peers y el orderer
  ### 3.3.5 Union de componentes y creacion de la red
 ## 3.4 Implementacion de los smart contracts y adquisicion de datos mediante IoT
  ### 3.4.1 Contrato inteligente y funciones implementadas dentro de la blockchain
  ### 3.4.2 El ESP32 para la recopilacion de datos utilizando diferentes sensores.
   #### 3.4.2.1 Implementacion de la cámara OV2640
   #### 3.4.2.2 Uso de la galga y envio de información
 ## 3.5 Desarrollo de la dApp e interconexion mediante el gateway de Hyperledger Fabric
 ### 3.5.1 Funcionamiento de la dApp
  #### 3.5.1.1 Diseño y funciones de la dApp
  #### 3.5.1.2 Funcionamiento en el lado del Servidor

# 4. Conclusiones









