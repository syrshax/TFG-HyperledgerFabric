#### 1 RESUMEN KEYWORDS ABSTRACT KEYWORDS
Este presente trabajo busca explorar y analizar las nuevas posibilidades y caracteriticas innatas que posee la tecnologia Blockchain para su uso en la rama de la industria de logística, en concreto veremos como se implementa teniendo como estudio el problema de **tracking de equipaje en aeropuertos**.

Gracias a la seguridad, inmutabilidad, descentralizacion y los famosos **smartcontracts**, la técnologia de bloques se introduce como una solución ideal para este tipo de aplicaciones, proporcionando un sistema robusto y confiable que asegura la auditabilidad de todo el proceso de seguimiento y de todas las partes involucradas.

Se utilizará una arquitectura blockchain basada en **Hyperledger Fabric**, junto microcontroladores de la familia **ESP32**, además de una pequeña interfaz gráfica y un modelo de datos que nos ayudará a analizar y comprender las etapas del proceso.

**Palabras clave: Blockchain, Hyperledger Fabric, IoT, ESP32**

This present work seeks to explore and analyze the new possibilities and inherent features that Blockchain techology has, for use in the logistics industry, specifically looking at how it is implemented by studying the problem of **airport luggage tracking.**

Thanks to security, inmutability, decentralization and the famous **smartcontracts**, blockchain is introduced as an ideal tecnhology solution for these types of applications, providing a robust and reliable system that ensures the auditabilty of the process and all involved parties.

We will use **Hyperledger Fabric** as our main blockchain framework, along with microcontrollers from the **ESP32** family, as well as a small graphical interface and a data model that will help us analyze the process. 


#### INTRODUCCION
En el vibrante mundo de la revolucion digital que actualmente vivimos, estamos presentes en una constante de cambios tecnologicos, donde cada inovacion redefine y remodela múltiples aspectos de nuestra vida y sociedad.

La tecnologia, palabra proveniente del griego antiguo [τέχνη](https://es.wiktionary.org/wiki/%CF%84%CE%AD%CF%87%CE%BD%CE%B7#Griego_antiguo) (tecnica, arte, industria, habilidad) y de [λόγος](https://es.wiktionary.org/wiki/%CE%BB%CF%8C%CE%B3%CE%BF%CF%82) logos (discurso, conocimiento), su propia raiz etimologica converge en el hacer y el saber entrelazandose mutuamente y otorgandonos la capacidad de crear y comprender. Por lo tanto, no es simplemente un medio mediante el cual ayuda a realizar tareas, sino también una expresión de nuestra comprensión y manipulación del mundo que nos rodea, un diálogo constante entre la teoría y la práctica.

De los múltiples problemas que abarca este trabajo, uno de los principales es como la confianza o "trust" entre partes implicadas juega un papel importantisimo en cualquier transacción de información que se realize en internet. En los sitemas convencionales existen al menos 3 partes implicadas. Una primera parte que ofrece un recurso, ya sea alquiler, compra etc. Estos pueden ser personas arrendatarios en Airbnb, gente que alquila sus coches en BlabLaCar por ejemplo. La segunda son los compradores o las personas que desean obtener dichos servicios o recursos y la tercera serian los intermediarios o plataformas que habilitan dichas transacciones **(Fraiberger, Samuel P. and Sundararajan)**. 

Por ejemplo, si alquilamos un coche en BlaBlaCar tenemos que depositar una confianza en la persona que nos alquila dicho coche, además tambien la plataforma, en este csao BlaBlaCar, nos da confianza en la seguridad del pago o en alguna posible incidencia que pueda pasar con el alquiler. La propia compañia incluso, proporciona una arquitectura tecnica, interface usuario, guia del proceso y propias reviews que mantienen la confianza entre todos los usuarios y partes implicadas. Como podemos observar, todo esto conlleva una "cadena de confianza" donde no tenemos transparencia y debemos creer ciegamente en las entidades que manejan dichos datos. **(The limits of trust-free systems: A literature review on blockchain technology and trust in the sharing economy.)**

Una de las principales cuestiones que llevaba tiempo sin resolvese, era la capacidad de ofrecer un sistema confiable, transparente y seguro donde poder registrar todo tipo de información, donde no existiera una entidad que tuviese un control total (como ocurre actualmente) de sobre nuestros datos.

Actualmente en las bases de datos convencionales, se almacenan y gestionan en una o varias ubicaciones concretas y generalmente bajo la administracion y supervision de una entidad o conjunto de reducido usuarios. Esto conlleva a que esas unidades o entidades centrales tengan todo el control sobre los datos, pudiendo gestionar la informacion y el acceso de la forma que deseen. 

Esto induce un problema añadido a la seguridad, y es que además al verse localizada en unos pocos puntos, un compromiso en el sistema podria afectar a toda la infraestructura.

Si miramos atŕas, el año 2008 queda marcado por la aparicion de un enigmatico personaje o grupo, desconocido hasta la fecha de hoy, denominado **Satoshi Nakamoto**. Nakamoto, introdujo al mundo una tecnología que estaba preedistinada desde un primer momento a permitir transacciones financieras peer-to-peer (P2P), sin la necesidad de una autoridad central, utilizando un **libro de cuentas** descentralizado e inmutable, concebido con el nombre **blockchain**. Aunque desde un primer momento esta tecnologia estuviera ligada a los entornos financieros, abrio las puertas a nuevas formas de pensar en como se transferian y almacenaba la información. 

La **Blockchain** tal y como se conoce actualmente, no es mas que un libro de cuentas digital descentralizado, que mantiene un registro de todas las transacciones en una cadena de bloques. Al estár descentralizado ningun organismo o entidad tiene un control total sobre la informacion guardada en dicho libro de cuentas, también denominado **ledger**. Gracias a esto cada nodo en la red contiene todas las transacciones y bloques. Esto significa que todos los nodos tienen una copia completa de toda la información de la red, asegurando que la información sea consistentemente replicada a través de todos los participantes siendo esta información constantemente validada reduciendo la posibilidad de fraude o manipulación, creando un sistema más transparente y seguro.**(A Multi-node Collaborative Storage Strategy via Clustering in Blockchain Network.)**


Otro de los problemas que vamos a abarcar en el transcurso de este trabajo es el uso de las ventajas que nos proporciona la tecnolgia **blockchain** para realizar un seguimiento o "tracking" de elementos en un proceso en concreto.

Cuando pensamos en realizar el seguimiento, en este caso, seguir el **trazo** de algún elemento, se nos viene a la mente tener una capacidad de rastreo y localizacion de un producto, lo que viene siendo obtener su informacion a lo largo de un proceso o cadena de procesos del cual este transita.

Que algo sea trazabable implica que se tenga una **visibilidad completa** a ojos del observador. Es necesario tener un imagen clara y precisa del recorrido, de como el producto es tratado y cual es su estado, desde el origen hasta el destino.

Utilizando la **Blockchain** como sistema, la trazabilidad se potencia extraordinariamente. La tecnología blockchain asegura que cada transacción o movimiento de un producto quede registrado de manera inmutable y transparente en la **blockchain**. Esto permite tener una transparencia total y completa del trayecto, así como las etapas que un producto pueda pasar, asegurando que la información sea precisa, confiable y accesible para todos los participantes autorizados en la red **(A Blockchain-Based Product Traceability System with Off-Chain EPCIS and IoT Device Authentication)**, mejorando la capacidad de seguimiento, localización de los productos y la veracidad y confiabilidad de los datos en cualquier punto de la cadena de suministro. **(Blockchain Technology for Enhancing Supply Chain Performance and Reducing the Threats Arising from the COVID-19 Pandemic)**

Y todos estos sistemas mencionados, se engloban en la denominada industria 4.0 **(Industria 4.0: Fabricando el Futuro)**, donde además esta presente el "internet de las cosas" o IoT, que no es mas que una interconexcion constante de dispositivos que trasnfieren cualquier tipo de informacion como por ejemplo: temperatura ambiente, humedad, informacion acerca de las etapas de un proceso... para dar un seguimiento efectivo a lo largo de toda la cadena de suministro **(Efficient Supply Chain Traceability Using IoT Technologies)**. Esta nueva etapa en la industria, mejora la productividad y eficiencia en procesos de manufactura y fabricación, permitiendo una mejor recolección de datos, siendo mas optima, segura y veráz. **(Blockchain-Based Internet of Things and Industrial IoT: A Comprehensive Survey)**

Incluyendo la utilizacion de dispositivos con capacidades IoT, concretamente para nuestra cuestion utilizaremos los microcontroladores de la familia ESP32, exploraremos como crear un sistema fiable, transparente, seguro y descentralizado, basandonos en un concepto para un sistema de tracking de maletas en aeropuertos, englobando un conjunto multidisciplinar de materias como blochckain, dispositivos hardware y creacion de aplicaciones web.

--------------

