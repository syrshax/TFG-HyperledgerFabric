### 1. El sector aeronautico en la gestion y trazabilidad de mercancias y equipajes.

#### Historia de la gestion y primeras etapas del sector aeronautico
La trazabilidad y gestión de mercancías y equipajes en el sector aeronáutico ha evolucionado significativamente a lo largo de los años, al ritmo de los avances tecnológicos y el creciente auge del comercio aereo.

Si nos remontamos a los primeros años del desarrollo de la industria de la aviacíon comercial, el procedimiento tradicional era que los pasajeros dejaban y recogían su equipaje en la pista ellos mismos. 

En esta época no existian las infraestucturas de hoy en dia con las comodidades que ello conlleva.

![[avion antiguo.png]]

Sin embargo, con el auge de la aviación y el incremento del uso de aviones como medio de transporte y mercancias,  estos se volvieron más grandes y los aeropuertos más complejos, lo que llevó a la necesidad de un nuevo sistema de manejo de equipaje que fuese capaz de gestionar el creciente flujo de viajeros y volumen de trabajo a los que se estaban viendo sometidos.

Así, se desarrolló un principio operativo en el que los pasajeros entregaban su equipaje en un mostrador de facturación, luego el equipaje era transportado a una ubicación donde el personal del aeropuerto especializado en carga y descarga rápida lo cargaba en carros, también conocidos como "baggage dollies". Al llegar el avión, el equipaje se descargaba y se transportaba a un punto de recogida, a menudo junto al edificio terminal, para ser recogido por los pasajeros​.

Inicialmente, los sistemas de manejo de equipaje utilizaban una tecnología ya usada en las cantereras de minerales y consistían en cintas transportadoras simples y rectas. Sin embargo, con el tiempo y el aumento del volumen de equipaje, se introdujeron nuevas instalaciones como carriles de clasificación, instalaciones de clasificación y estacionamientos (conocidos posteriormente como almacenamientos de equipaje). 

En 1971, se inventó el primer sistema automatizado de manejo de equipaje por BNP Associates, tecnología que se utiliza en todos los principales aeropuertos del mundo hoy en día. Se creo un sistema automatico que se encargaba de todo el manejo de equipajes, desde cintas mecanicas hasta software.​ (**BEUMER GROUP HOW DID THE BAGGAGE HANDLING SYSTEM DEVELOPED TRU THE YEARS - https://www.beumergroup.com/knowledge/airport/how-did-the-baggage-handling-system-develop-and-which-systems-are-used-in-airports-today/**)


#### Estructura y mecanismos actuales para la manipulación y estandares de mercancias.
En la actualidad, segun la Federal Aviation Administration (FAA) mas de 760 millones de personas han embarcado alguna vez en el año 2017, un 3.6% mas que años posteriores. (**Pekoske, D., 2018.**) Para que nos hagamos una idea de lo cuan grande es la industria de aviación en los Estados Unidos y es que contribuye mas de un 6% del PIB del país, **$19,386.2 trillion** (americanos) lo que supondria un total de **$1,163.172 trillion**  (PIB AMERICA 6%). Comparandola con nuestro querido pais, su industria de aviacíon mueve mas que todo el PIB de España(**1.313 trillion USD**). 


La complejidad de la infraestructura de los sistemas actuales dependen del *layout del aeropuerto* y de la capacidad disponible en cada momento, además no todo el aeropuerto tiene la misma capacidad de administrar los equipajes, dependemos de la distancia entre aviones, la localización de los parkings, las aereas de check-in o check-out por ejemplo. Estos sistemas de manipulación de mercancias y equipajes se rigen por varios standares de asociaciones tales como **IATA** (**Asociación Internacional de Transporte Aéreo**) la **TSA (Administración de Seguridad en el Transporte de EE. UU.)** y **FAA (Administración Federal de Aviación de EE. UU.)**.

![[estructura_actual_airports.png]]

La **Asosiacion Internacional de Transporte Aereo** define dentro de su **Manual de Manejo en Aeropuertos (AMH)** unos procesos comunes que identifican como se debe proceder en el manejo de mercancias y equipajes dentro de los aeropuertos. Estos son algunos de los procesos que hace referencia la **IATA** :

- **Check-in de equipaje**: El proceso comienza en los mostradores de check-in, donde los pasajeros entregan su equipaje a la aerolínea. Aquí, cada maleta se etiqueta con información esencial como el destino y el seguimiento. Este proceso se facilita a través del uso de tecnología de usuario común (CUTE), que permite a los agentes de servicio del aeropuerto manejar el equipaje a través de múltiples aerolíneas en un solo sistema. 
- **Screening de Equipaje de Bodega (Hold Baggage Screening, HBS)**: Después del check-in, el equipaje pasa por un proceso de seguridad conocido como screening de equipaje de bodega (HBS). Este procedimiento es crucial para detectar y prevenir la carga de artículos prohibidos o peligrosos. Se utiliza un scaner de rayos X. 
- **Almacenamiento de Equipaje Temprano (EBS):** El EBS es una solución de almacenamiento para equipajes que se registran mucho antes de la hora de salida de un vuelo. Este sistema permite a los aeropuertos manejar eficientemente los picos de carga de equipaje, almacenando las maletas hasta que sea el momento de cargarlas en la aeronave. Los sistemas automatizados que se utilizan pueden incluyen carruseles, sistemas de elevación vertical, y vehículos guiados automáticamente (AGVs) que transportan y almacenan el equipaje en estanterías o contenedores hasta que sea necesario su uso.


Gracias a estos procedimientos y estandares utilizados que recoje la IATA (2004), los datos, información y mercancias de millones de usuarios se ven beneficiados, al tener unas pautas establecidas y reglas claras.

Aun así, nuevas tecnologias emergen en estos tiempos tan cambiantes y innovaciones como la **blockchain** y los dispositivos **IoT** están revolucionando los sistemas de trackeo, gestión y transferencia de información.

Tenemos como ejemplo el aeropuerto Internacional de Washintong D.C, que utiliza dispositivos IoT introduciendo tecnologia de reconocimiento facial. Tambien el uso metodos para el rastreo inteligente de equipaje que se extravia. **6 tecnologías que están revolucionando la experiencia de vuelo en los aeropuertos de todo el mundo** https://mex.nec.com/es_MX/press/PR/20190221064809_28823.html

Además, se ha propuesto una arquitectura informática para aeropuertos que integra la tecnología RFID, IoT y Google Indoor, que incluye una aplicación para smartphone, kioscos y etiquetas, contribuyendo así a la creación de aeropuertos inteligentes. **Aeropuertos inteligentes: aceptación de la tecnología por parte de los pasajeros**



### 2. Blockchain, como gestora de datos y tracker inmutable.

#### Los inicios de la tecnologia Blockchain

En el año 2008, apareció la primera aplicación de la tecnologia blockchain, a muchos les sonará el nombre de Bitcoin. Esta fue desarollada por un enigmatico Satoshi Nakamoto el cual adquirio este nombre como un pseudonimo y cuya identidad sigue todavia en paradero desconocido.

La blockchain de Bitcoin, fue la primera aplicaci´on real a la que fue sometida la esta tecnologia a ojos de un público mas general y no solo en entornos de desarollo. Estaba destinada particularmente un ambito dentro de las finanzas, que hoy dia conocemos como "criptomonedas" o cripto activos. 
Para sus desarolladores Bitcoin tenia el proposito de ser una alternativa a los bancos tradicionales para dejar de depender de estos como intermediaros y de asegurarle al usuario que el activo financiero, este caso los Bitcoins, eran suyos ya que una de las ventajas de esta tecnologia es proporcionar soberania a cada usuario sobre la custodia de sus activos.

![[bitcoin3.png]]

Para las transacciones, Bitcoin se basa en que unicamente necesitas una marca criptografica identificativa  (se basa en una combinación de claves publico - privadas) en lugar de tener que depositar la confianza en un tercero para realizar transacciones (en este caso el tercero puede ser cualquier intermediaro, un banco por ejemplo). 

Estas transacciones debido a su carga criptografica son actualmente *(referencia buscar)* computacionalmente imposibles de modificar, esto genera una gran proteccion a los vendedores de posibles fraudes que puedan sufrir, y si ademas aplicamos mecanismos de custiodia (proporcionados por un tercero, ya que la propia tecnologia Bitcoin en sí no los posee) tambien otorga a los compradores seguridad, pudiendo por tanto proteger sus Bitcoins de recibir cualquier tipo de ataque malicioso.

Bitcoin se encontro con algunos problemas en su desarrollo, uno de ellos fue el problema del ”doble gasto". En concreto trataba de como solventar el problema de que una moneda pudiese ser utilizada varias veces en una misma transacción pudiendo ser copiada. 


Para ilustrarnos tengamos como ejemplo:

"Imaginemos que Alice tiene 1 bitcoin y quiere comprar dos artículos diferentes de dos vendedores diferentes, Bob y Carol. Si Alice intenta enviar ese mismo bitcoin tanto a Bob como a Carol al mismo tiempo, estaría intentando hacer un doble gasto.

Solo una de esas transacciones (la que sea confirmada primero por la red) será aceptada y añadida a la blockchain. La otra transacción será rechazada.

Una vez que recibes bitcoins en tu **wallet** y se confirma la transacción, esos bitcoins son tuyos y puedes gastarlos como desees en futuras transacciones. La clave aquí es que una vez que una transacción ha sido confirmada, esos bitcoins específicos no pueden ser gastados dos veces en el mismo momento."
**(Bitcoin whitePapper)**


![[bitocin1.png]]


La solución propuesta para el problema del doble gasto en Bitcoin fue la implementación de un sistema donde todas las transacciones se registran en una cadena de bloques la ya muchas veces mencionada **blockchain**. Esta blockchain actúa como una base de datos descentralizada y distribuida en la que se almacenan todas las transacciones. (https://traders.studio/como-evita-una-cadena-de-bloques-el-doble-gasto-en-bitcoins/#:~:text=Este%20problema%20de%20%C2%ABdoble%20gasto%C2%BB,PoW)

![[bitcoin2.png]]

Para asegurar y validar estas transacciones, se introduce la figura del 'minero'. Los mineros son nodos especializados en la red que participan en el proceso de prueba de trabajo, resolviendo desafíos criptográficos complejos para agregar nuevos bloques a la cadena. Una vez que un minero ha encontrado un bloque válido, este se añade a la blockchain y las transacciones contenidas en ese bloque se consideran confirmadas.

Como incentivo por este trabajo, los mineros reciben una recompensa en forma de bitcoins recién creados, así como las tarifas de las transacciones que han incluido en el bloque. Esta recompensa motiva a más participantes a unirse al proceso de minería, fortaleciendo la seguridad y estabilidad de la red. (https://academy.binance.com/es/articles/how-to-mine-bitcoin?ref=HDYAHEES)



#### Fundamentos de la blockchain y base criptografica de funcionamiento

Como ya hemos definido multiples veces de forma general como funciona la tecnlogia **blockchain**, vamos a indagar un poco mas en su principio de funcionamiento y los elementos que la componen.

Cuando iniciamos una blockchain, se comienza definiendo el primer bloque de la cadena, el cual es denominado **bloque genesis**. Este bloque sirve como punto de partida contiene las bases por las cuales se regiran los subsiguientes bloques. **(Reyna, A., Mart´ın, C., Chen, J., Soler, E., D´ıaz, M.: On blockchain and its integration with IoT. Challenges and opportunities. Futur. Gener. Comput. Syst. 88, 173–190 (2018))**. Él establece ciertas reglas y parametros basicos del sistema, como tipo de consenso, tamaño m´aximos de informaci´on que puede albergar cada bloque... Aunque esto depende del tipo de blockchain que se utilize, en nuestro caso en concreto de uso de Hyperledger Fabric, el bloque genesis nos permite todas estas configuraciones. (https://hyperledger-fabric.readthedocs.io/en/latest/configtx.html)

Los elementos en los que se compone la cabezera de cada bloque son los siguientes:

![[hash1.png]]

La cadena de bloques quedaria así:

![[hash2.png]]


![[Pasted image 20231121190053.png]]

---------------

Cada bloque en una blockchain se identifica mediante un _hash_. Este **hash** se genera a partir de la información contenida en el bloque actual junto con el _hash_ del bloque anterior. Un _hash_ se puede definir como:

Una función HH que procesa una entrada finita de información arbitraria hacia una salida de longitud fija, referida como valor _hash_ (**Cryptographic Hash Functions**). En la práctica, la longitud de la salida es alrededor de 160 bits, y esta salida se denomina _hash criptográfico_.

Esta estructura permite verificar la integridad de todas las transacciones pasadas gracias a un _árbol de Merkle_. El nombre de *arbol de Merkle* viene dado gracias a su creador Ralph Merkle **(Ralph C. Merkle. A digital signature based on a
conven- tional encryption function. In Carl Pomerance, editor, Advances in Cryptology — CRYPTO ’87, pages 369–378, Berlin, Heidelberg, 1988. Springer Berlin Heidelberg.)** Un _árbol de Merkle_ organiza los _hashes_ de las transacciones en una estructura de árbol binario, donde cada nodo no terminal contiene el _hash_ de la concatenación de los _hashes_ de sus nodos hijos. Solo es necesario mantener el _hash raíz_ del árbol de Merkle, que es el _hash_ del nodo más alto, para verificar ciertos datos específicos. Este _hash raíz_ se incluye en el encabezado del bloque, y al comparar el _hash raíz_ almacenado con el _hash raíz_ calculado a partir de las transacciones presentes, se puede verificar que las transacciones no han sido alteradas.

![[hash3.png]]

Esto nos permite comprobar si algún bloque ha sufrido alguna modificación sin la necesidad de verifcar todo el conjunto. Como ya hemos comentado, el hash se genera con un conjunto de informacion que contiene el bloque, si esta informacion se ve alterada, el hash de salida, el *hash criptografico*, se vera modificado y el arbol de Merkle, su raiz, tambien se ver´a modificada. Con esto se comprueba la integridad de los datos de una forma mucho mas liviana en terminos de poder computacional.

Otra aspecto crucial de la _blockchain_ es la manera en que **se transmiten los datos a todos los nodos** y cómo **los nodos alcanzan un consenso sobre la validez de esa información**.

Cuando efectuamos una transacción dentro de la red blockchain, necesitamos proporcionar una clave criptográfica válida para autorizar dicha transacción. Uno de los métodos criptográficos utilizados es la Criptografía de Curva Elíptica (ECC, por sus siglas en inglés, de _Elliptic Curve Cryptography_). **(Elliptic Curve Cryptography and its Applications)**. 

Suponiendo que nuestra clave criptográfica sea aceptada por la red, la transacción mencionada se llevará a cabo. Una transacción se interpreta como una transferencia de datos entre dos usuarios, y necesita ser validada por los nodos en la red.

Para propagar y validar transacciones, se utiliza un _protocolo de inundación_ conocido como _Gossip Protocol_. Dependiendo de la configuración inicial de nuestra blockchain, ciertos nodos o todos los nodos, validarán la transacción. Este protocolo replica la información a los nodos configurados, y la validación de la transacción se logra a través del _consenso de la red_, según se describe en el libro _Bitcoin and Blockchain Security_ de Ghassan Karame y Elli Androulaki."

El tema del consenso tiene sus raíces en un contexto militar antiguo, donde se presenta un escenario en el que varios generales deben decidir entre atacar o defender. Esta situación dio origen al nombre del _Problema de los Generales Bizantinos_ (**The Byzantine Generals Problem**). Este problema, formulado por Pease, Shostak y Lamport en 1982, se ha convertido en una cuestión central en la teoría de sistemas distribuidos y la ciencia de la computación, intentando alcanzar un consenso en una red distribuida, especialmente en presencia de nodos malignos que pueden proporcionar información falsa. (**A Survey on Byzantine Agreement Algorithms in Distributed Systems**).

El consenso en una red distribuida es un pilar fundamental en la tecnología blockchain. Se define como el acuerdo alcanzado entre las diversas partes de la red. Dado que los nodos no pueden verificar su información con referencia a un nodo central, deben hacerlo entre ellos. En la blockchain, resolver el **Problema de los Generales Bizantinos** permite asegurar que todos los nodos lleguen a un consenso sobre la validez de las transacciones y los bloques, incluso cuando existen nodos malintencionados en la red. Esta resolución del consenso es crucial para mantener la integridad y la seguridad de la red blockchain.

Los tipos de consensos más extendidos son el Proof-of-Work (PoW), donde cada nodo tiene que resolver operaciones matemáticas difíciles y es el protocolo utilizado por Bitcoin. El Proof-of-Stake (PoS) se basa en que la probabilidad de crear un bloque se relaciona con la cantidad de tokens que un nodo tiene Ethereum está en el proceso de transición hacia PoS con su actualización a Ethereum 2.0. Por último, el Practical Byzantine Fault Tolerance (PBFT) es un protocolo utilizado por blockchains como Hyperledger Fabric, que se enfoca en la tolerancia a fallos en sistemas con una participación controlada y conocida. (**Blockchain without Waste: Proof-of-Stake**) 


-----------------------
#### DIFERENTES TIPOS DE REDES BLOCKCHAIN (NUEVO APARTADO? nota: tengo que ver si hablo sobre algo de esto o no,  si encajarlo en algun lugar.)

Como se puede llegar a pensar, no todas las redes blockchains son iguales. Dependiendo del algoritmo de consenso o su arquitectura interna, algunas redes poseen propiedades unicas respecto a otras. 

Una caracteristca que define de forma general el uso de un tipo de blockchain respecto a otra es **la permisionabilidad que poseen.** En gran escala podemos diferenciar 3 tipos de redes:

- **Blockchains publicas** : Tenemos como ejemplo las redes de **Bitcoin** o **Ethereum**, que cualquier usuario de internet puede interactuar con ellas, sin una necesidad de poseer autorizacion o identificacion. Estas redes al ser publicas, todo las transacciones son consultables por cualquier usuario y si se conoce nuestra direccion de wallet, se puede explorar toda nuestra actividad. Estas redes poseen una gran seguridad debido a la enorme cantidad de nodos que poseen. Por contrapartida, son redes lentas debido a su gran descentralizacion.

- **Blockchains privadas y/o de consorcio** : Como su nombre indica, unicamente pueden participar usuarios que estan autorizados y registrados en la red por el administrador. Estas redes se utilizan en el ambito empresarial ya que no se desea que toda la informacion sea publica, aunque aqui hay matizes, ya que en el caso de **Hyperledger Fabric**, se puede configurar para hacer ciertos datos publicos que sean visibles a cualquier usuario sin necesidad de que este autorizado en la red. Tambien se le denomia de consorcio ya que puede ser, que no unicamente una organizacion se encarge de la gestion y mantenimiento de la red, ademas permite a varias empresas de diferentes ambitos participar y compartir informacion. Estas redes proporcionan por norma general una mayor eficiencia. Otro ejemplo de red privada es **Ripple**.

- **Blockchains hibridas**: Permiten el acceso a ciertas partes de la red a usuarios que no esten autorizados. Esta limitada la administracion de la red pero usuarios que no esten autentificados pueden llevarla a cabo. Tenemos como ejemplo redes como **Polkadot y Cosmos.**




---------- 


#### SMART CONTRACTS 

Un aspecto central en la evolución de las blockchains es la incorporación de los _smart contracts_ o contratos inteligentes, que añaden una capa de funcionalidad y automatización que va más allá de las simples transacciones de criptomonedas. Estos contratos, inicialmente propuestos en la década de 1990 por Nick Szabo, han encontrado en la blockchain la plataforma ideal para su implementación y despliegue​. https://www.sciencedirect.com/science/article/pii/S0167739X19316280 . Por consiguiente este nuevo avanze a destacado como una de las aplicaciones más relevantes y revolucionarias dentro de la tecnología blockchain.
Los _smart contracts_ se almacenan, replican  y se actualizan dentro de la **blockchain**.

Estos contratos,  se traducen en programas informáticos que codifican cláusulas contractuales, de ahí su nombre, las cuales se ejecutan automáticamente cuando se cumplen condiciones predefinidas. Diferente a los contratos convencionales, que suelen requerir de una tercera parte como un intermediario para su ejecución.



Como el ejemplo que de describió al principio del capitulo de introduccion, un _smart contract_ puede ser un acuerdo entre un comprador y un vendedor/proveedor. El proveedor envía un catálogo de productos al comprador a través de la red blockchain. Este catálogo, junto con los términos de envío y pago, se almacena y distribuye en la blockchain, permitiendo al comprador obtener información del producto y verificar la autenticidad y reputación del proveedor simultáneamente. Posteriormente, el comprador envía el pedido con la cantidad especificada y la fecha de pago a través de la blockchain, formando así un contrato de compra. Todo este procedimiento se realiza sin la intervención de una tercera parte.

**FOTO FIGURA**

![[smartcontractinteractionSuplierBuyerCarrier.png]]

https://www.sciencedirect.com/science/article/pii/S0167739X19316280#:~:text=Blockchain%20technology%20is%20enabling%20smart,when%20predefined%20conditions%20are%20met

Aqui tenemos un ejemplo real lenguaje de codigo Solidity, utilizado en redes como Ethereum, que sirve para enviar Ether, en este caso en concreto para pagar por un servicio.

```javascript
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract SendMoneyExample {
    address payable public owner;

    // Constructor para establecer el propietario del contrato
    constructor() {
        owner = payable(msg.sender);
    }

    // Función para recibir Ether, la función debe ser 'payable'
    receive() external payable {}

    // Función para enviar Ether a un cliente desde el contrato
    function sendMoney(address payable _to, uint256 _amount) public {
        require(msg.sender == owner, "Solo el propietario puede enviar dinero");
        require(address(this).balance >= _amount, "Saldo insuficiente");
        _to.transfer(_amount);
    }

    // Función para consultar el saldo del contrato
    function getBalance() public view returns (uint) {
        return address(this).balance;
    }
}
```

Aplicando un smart contract en este supuesto ejemplo, obtenemos varias ventajas o mejoras comparandolos con unos contratos convencionales:

 - Reducimos riesgos: Ya que el smartcontract se ejecuta en la blockchain, esta hace que el contrato sea dificilmente modificable mediante algun tipo de fraude malintencionado.
 
 - Reducimos costes: Se reducen los costes aplicados a intermediaros que gestionan este tipo de informacion o servicios.
 
 - Mejora la eficiencia: Al reducir el intermediario y con la posibilidad de aceptar conciones de forma automatica si X o Y condicion se cumple, se mejora la velocidad en trámites, confirmación de recepción de productos...


Los smartcontracts como todo proyecto de software esta atado a un proceso o ciclo de vida y este puede quedar definido en las fases de:

- Creacion: Esta es la fase inicial donde se diseña y desarrolla el código del _smart contract_. Aquí, se define la lógica del contrato, las funciones, las condiciones y los términos bajo los cuales se ejecutará el contrato. También en esta fase se establecen las partes involucradas y los activos o datos que serán gestionados por el contrato.

- Deployment: Una vez creado, el _smart contract_ se despliega en la blockchain. En esta fase, el contrato se convierte en una parte inmutable de la blockchain, lo que significa que una vez desplegado, el código del contrato no puede ser alterado. 

- Ejecucion: Los _smart contracts_ se ejecutan automáticamente en respuesta a los desencadenantes específicos definidos en el código del contrato. Cuando se cumplen las condiciones predefinidas, el contrato se ejecuta sin necesidad de intervención humana. 

- Finalizacion: La finalización ocurre cuando se han cumplido todas las condiciones del contrato y se han ejecutado todas las funciones definidas en el contrato. En algunos casos, un _smart contract_ puede tener una función de autodestrucción que se activa al finalizar, eliminando el contrato de la blockchain y liberando los recursos utilizados por el contrato.

**(https://es.wikipedia.org/wiki/Contrato_inteligente#:~:text=Un%20contrato%20inteligente%20,ciertas%20acciones%20sucedan%20como)**
**(https://www.bbva.com/es/innovacion/smart-contracts-cinco-preguntas-clave/)**


![[lifecyclesmartcontract.png]]



----------------



### EL ENTORNO IOT Y SU APLICACION EN BLOCKCHAINS

#### Los dispositivos IoT y metodos de transferencia de informacion
Los dispositivos IoT posibilitan un cambio de ruta respecto a nuestro escenario actual donde unicamente ciertos servicios y dispositivos utilizan el Internet unicamente como una herramienta, a pasar a tener "todas las cosas conectadas" a Internet.

La palabra definicion IoT "Internet of Things" o en Español "Internet de las cosas" define literalmente que cualquier cosa, ya sea una entidad o un objeto que tenga una manera de identificarse de forma unequivoca, ser referenciado y que tenga las capacidades necesarias de comunicacíon lograr formar una red entre varios de estos dispositivos. Tenemos varios ejemplos de dispositivos que pueden ser tratados y utilizados como **IoT devices**,  tales como: Identificadores de Radio Frecuencia (RFID), sensores, actuadores, telefonos moviles... 

El enfoque básico dentro del modelo de IoT consiste en introducir una gran cantidad de "cosas" (dispositivos de bajo nivel, sin usuario y sin interfaz) en la arquitectura de Internet, facilitando la monitorización y control remotos. La innovación en IoT es el resultado de muchos dominios, desde tecnologías de hardware facilitadoras hasta componentes de software con varios mecanismos, funciones y protocolos diseñados para integrar de manera efectiva los mencionados dispositivos de bajo nivel

![[emergionIOt.png]]


El concepto de IoT radica en el impacto que genera en diversos aspectos de la vida cotidiana y en la conducta de los usuarios potenciales. Desde la perspectiva de un usuario privado, los efectos más reconocibles de la incorporación de IoT se manifestarán tanto en el ámbito laboral como en el doméstico. En este escenario, podemos identificar la dómitica como un uso en el ámbito privado, asi mismo, los moviles que utilizamos diariamente. De manera similar, desde el punto de vista de las empresas y corporaciones, los usos más evidentes se muestran en áreas como la automatización, la manufactura industrial, la logística, la gestión de procesos empresariales y el transporte inteligente de personas y mercancías.

Este nuevo paradigma abre las puertas a la optimización y la innovación, permitiendo la creación de soluciones que antes eran inimaginables. Los avances tecnológicos que lleva consigo IoT prometen transformar la manera en que interactuamos con el mundo que nos rodea, presentando oportunidades para mejorar la eficiencia y la calidad de vida. En el ámbito empresarial, las posibilidades de monitorización y gestión en tiempo real ofrecen una ventaja competitiva significativa, permitiendo una toma de decisiones más rápida y basada en datos. **Internet of things: Conceptual network structure, main challenges and future directions**

---------

Los dispositivos IoT son utilizados de forma muy amplia en los **sistemas distribuidos**, tales como blockchain y cloud computing, ya que estos sistemas pueden otorgar los dispositivos IoT caracteristicas que ellos no poseen, tales como una capacidad computacional mas alta (los dispositivos IoT son utilizados en estos casos como meros sensores y emisores de informacion) y en el caso de utilizarse en entornos blockchain, los dispositivos se benefician de la seguridad y confianza que otorga esta tecnologia.

#### Las comunicaciones
Para establecer una comunicacion entre dispositivos IoT o si se quieren implementar en **los sistemas distribuidos** ya mencionados, debemos utilizar protocolos que permitan una comunicacion los dispositivos. Muchos protocolos de comunicación de propósito general utilizan UDP/TCP en la capa de transporte. Si los dispositivos IoT deben ser accesibles desde navegadores web y son utilizados de forma una forma diversa, se podria utilizar HTTP.  Si se desea establecer un protocolo especializado en mensajeria IoT entre varios dispositivos, utilizariamos MQTT.   **Messaging Protocols for IoT Systems—A Pragmatic Comparison https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8540579/
¿Qué es MQTT? - https://aws.amazon.com/es/what-is/mqtt/**


![[httpmqttdiagrama.png]]


Estos protocolos buscan tener una latencia muy baja, que tengan la maxima capacidad de envio de paquetes posible y que consuman muy poca energia. Estas caracteristicas las condiciona el tipo de dispositivo que normalmente se utliza, que suelen ser microcontroladores de muy bajo consumo y baja capidad computacional. 

Existe una amplia gama de protocolos para utilizacion en aplicaciones IoT. Los mas protocolos mas utilizados y preferidos para utilizarse en aplicaciones que involucren dispositivos y comunicaciones IoT son el **HyperText Transfer Protocol (HTTP) usado con REST y el MQTT**.  

![[IOTProtocoloStack.png]]

**A survey on communication protocols and performance evaluations for Internet of Things. https://www.sciencedirect.com/science/article/pii/S2352864822000347**

##### REST
**REST** es un termino que se utiliza para describir la arquitectura en redes que utilizan un protocolo simple basado en **HTTP** para conectar los dispositvos. La arquitectura **REST** no es un standar per sé, es un modelo o estructura que utilza patrones y definiciones de **HTTP**, **Unit Resource Locator** (URL) y lenguaje de marcado **XML** entre otros. Normalmente a esta arquitectura tambien se le denomina **RESTful** y es tan usada porque es muy flexible y muy facil operar con ella. 
En la arquitectura **REST**, cada componente se define como un recurso. Estos recursos pueden ser un archivo de texto, página **HTML**, imagen, video, o cualquier tipo de datos. El servidor **REST** hace que cada recurso sea accesible asignando un Identificador de Recurso Uniforme (**URI**). Los clientes pueden reformatearlos o usarlos directamente accediendo a ellos a través de URLs creadas con **URIs**. No hay restricción sobre el formato del recurso en la arquitectura **REST**. Los datos pueden transmitirse en muchos formatos diferentes dependiendo de la aplicación. Estos formatos pueden ser texto plano, **JSON**, o XML, **etc**., comúnmente utilizados en Internet. En la arquitectura **REST**, los mensajes se transmiten en el sistema de solicitud-respuesta a través de **HTTP**. El cliente envía el mensaje como una solicitud **HTTP** y el servidor responde con una respuesta **HTTP**.

![[httpexplained.png]]

##### MQTT

MQTT (Message Queuing Telemetry Transpor) es un protocolo de transporte de mensajes basado en una arquitectura de publicación-suscripción. Este protocolo fue ideado para dispositivos con recursos limitados, con el objetivo de ser de bajo coste, codigo abierto, ser fiable y sencillo.

MQTT opera con clientes que interactúan a través de intermediarios y distribuyen los mensajes entre ellos. Un cliente MQTT puede asumir el papel de publicador o suscriptor. La información del mensaje incluye datos y temas. Los clientes interactúan entre sí a través del tema correspondiente que es distribuido por el intermediario. De esta manera, el intermediario MQTT almacena y publica la información del publicador a los suscriptores. La Figura 5 muestra el modelo de comunicación MQTT.

En el protocolo MQTT se definien tres niveles de Calidad de Servicio (QoS), que son: al menos una vez, al menos una vez y exactamente una vez, para satisfacer diferentes requerimientos de aplicación. MQTT utiliza TCP/IP para la transmisión de datos y Seguridad en la Capa de Transporte/Capa de Sockets Seguros para garantizar la seguridad en las comunicaciones. El tamaño del mensaje puede variar según los requerimientos de la aplicación hasta 256 MB con una cabecera de 2 bytes. 

![[mqttexplained.png]]

**A survey on communication protocols and performance evaluations for Internet of Things. https://www.sciencedirect.com/science/article/pii/S2352864822000347**

-----------

#### La tecnologia Blockchain en entornos IoT 

La tecnología del Internet de las Cosas (IoT) y la blockchain está abriendo nuevas fronteras en la forma en que interactuamos y gestionamos los datos en el mundo digital. Los dispositivos IoT encuentran en la blockchain un aliado que asegura integridad, la seguridad y la confiabilidad de la información que manejan.

Los dispositivos IoT desempeñan un papel muy importante en la captura de datos en tiempo real que facilitan la toma de decisiones y las automatizaciones. Al mismo tiempo, la blockchain respalda estos proyectos proporcionando un registro inmutable. Estos dispositivos IoT pueden enviar datos a **redes privadas de blockchain**, creando así registros a prueba de alteraciones que están accesibles unicamente para las entidades configuradas. Esta característica no solo promueve la transparencia sino que también facilita la colaboración y el intercambio de información en un ecosistema donde por ejemplo esten involucrados varios equipos desarrollando un producto, o empresas que deseen compartir informacion confidencial.

Como ya hemos visto, las **redes blockchains** no todas son iguales. Ademas de poder tener tipos de consenso diferentes, protocolos y configuraciones. Muchas blockchains ya tienen un uso predefinido, por lo que hay que elegir la que se adapte mejor a nuestras necesidades.

Vamos a presentar las 3 mejores diferentes tipos de de **redes permisionadas** y de uso empresarial que existen y se utilizan actualmente en el mercado y compararemos la mejor para nuestra **prueba de concepto**.

- **Quorum (Enterprise Ethereum)** : Quorum es una plataforma de blockchain empresarial que se deriva como una bifurcación del cliente público de Ethereum, 'geth', con varias mejoras a nivel de protocolo para satisfacer las necesidades empresariales en 2016 por JP Morgan Chase, una de las organizaciones financieras más grandes del mundo, con el propósito de desarrollar un cliente Ethereum empresarial que permita a las empresas aprovechar y beneficiarse de la tecnología blockchain​. 
  Quorum está diseñado para operar en un entorno con permisos, a diferencia de Ethereum, donde toda la información de transacciones y tokens es visible en un libro mayor público. Esta privacidad es considerada una característica necesaria para la implementación de la tecnología blockchain dentro de redes privadas "empresariales"​.
 
 Al ser una variacion del cliente de Ethereum, el lenguaje de programacion que se utliza en los smartcontracts es **Solidity**. Estos contratos inteligentes se ejecutan bajo una maquina virtual llamada **Ethereum Virtual Machine**, el concepto es igual que la **JVM** de Java.

- **Corda R3**: R3 Corda es una plataforma de tecnología de registro distribuido (DLT) especialmente diseñada para servicios financieros. Es un proyecto de blockchain de código abierto creado específicamente para el uso empresarial desde su inicio. Corda fue desarrollado en 2019 por R3, una empresa de software blockchain empresarial, en colaboración con más de 200 socios tecnológicos e industriales. La plataforma es confiada por instituciones reguladas para permitir la tokenización de activos digitales y monedas, acelerar los procesos de liquidación y automatizar procesos comerciales complejos.

  Los contratos inteligentes en **Corda** estan programados principalmente en **Java o Kotlin**, ejecutandose en la **JVM (Java Virtual Machine)**. 
  
  Enterprise Blockchain Protocols: A Technical Analysis of Ethereum vs Fabric vs Corda https://www.kaleido.io/blockchain-blog/enterprise-blockchain-protocols-a-technical-analysis-of-ethereum-vs-fabric-vs-corda#:~:text=For%20these%20permissioned%20chains%2C%20three,designed%20for%20the%20financial%20industry

- **Hyperledger Fabric**: Creada inicialmente por **The linux fundation** pero mas tarde amparada por Red Hat de IBM. Hyperledger Fabric es una plataforma de tecnología de registro distribuido (DLT) de grado empresarial y de código abierto, diseñada para desarrollar aplicaciones o soluciones con una arquitectura modular.  Esta arquitectura modular hacer que sea muy sencillo añadir nuevos componentes modificar la topografia de la red, facilitando mucho las gestiones en entornos empresariales. Con la participación de más de 120 000 organizaciones y la colaboración de más de 15 000 ingenieros, Hyperledger Fabric ofrece un enfoque único para el consenso que permite el rendimiento a escala, al mismo tiempo que se respeta la demanda de privacidad de datos de las empresas. **HYPERLEDGER FABRIC https://www.ibm.com/es-es/topics/hyperledger**



Para nuestro caso de uso en concreto, basandonos en el articulo **Permissioned blockchain frameworks in the industry: A comparison https://www.sciencedirect.com/science/article/pii/S2405959520301909?via%3Dihub** donde se realiza un **benchmark** donde se comparan diferentes caracteristias como:

- Escalabilidad
- Privacidad
- Seguridad
- Velocidad y latencia
- Adopcion

Despues de analizar todos estas caracteristicas se opto por **Hyperledger Fabric** para la implmentación en nuestra prueba de concepto, ya que se ajusta de la mejor forma a nuestras necesidades.


![[scoringBlockchians.png]]


Buscamos sobretodo velocidad en las transacciones, ya que como veremos en el siguiente capitulo, para interactuar con dispositivos IoT la velocidad y la baja latencia en las comunicaciones hace a **Hyperledger Fabric** un candidato superior prente a sus competidoras. 
 



----------------


Esta tabla nos muestra la capacidad que tienen los diferentes algoritmos en las diferentes blockchains para transmitir información. Las transacciones (tx) pueden representar eventos, operaciones o acciones especificas de la red. Es el intercambio de información dentro del bloque. una de las caracteristicas esenciales que una red blockchain debe tener para participar en entornor IoT es **la velocidad de transaccion o (TX/s)**. 

![[TABLA EVALUACION APPLIACION.png]]

**New Blockchain-Based Architecture for Service Interoperations in Internet of Things https://ieeexplore.ieee.org/document/8764459**


















La infraestructura segura que proporciona la blockchain es esencial para que los dispositivos IoT trabajen de manera integrada. La coordinación entre estos dispositivos es crucial para evitar problemas y asegurar un funcionamiento armonioso, y aquí es donde la blockchain se destaca al ofrecer una plataforma descentralizada y segura. Esta tendencia hacia una infraestructura descentralizada y protegida establece un nuevo estándar en la manera en que los dispositivos IoT interactúan y cooperan entre sí, sentando las bases para un futuro más seguro y eficiente en el ámbito de la tecnología y la gestión de datos.