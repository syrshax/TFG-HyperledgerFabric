MANAGIN IOT DEVICES WITH BLOCKCHAIN

https://ieeexplore.ieee.org/abstract/document/7890132?casa_token=K7rWuAa506UAAAAA:cc7P0A1OT8uOQB_MNNsGu6aQfwB1UDwNQnqY2u8eJnCfvaXVF2mlE9WefHrY5OQyqO8YcRbb


COMO HACER RED GETH CON PROOF OF AUTHORITY

https://hackernoon.com/setup-your-own-private-proof-of-authority-ethereum-network-with-geth-9a0a3750cda8


Blockchain and IoT Integration: A Systematic Survey

https://www.mdpi.com/1424-8220/18/8/2575


An IoT-blockchain architecture based on hyperledger framework for health care monitoring application 

https://hal.inria.fr/hal-02434834/



Hyperledger Fabric vs Hyperledger Besu vs Quorum vs Ethereum(Geth) 

- La cosa es que, realmente lo que mas me gustaria seria usar Eth, por su
escalabilidad, su compromiso, su desarrollo opensource y descentralizado
y por su importancia. Creo que es la opcion mas correcta.

Sus limitciones son a poca velocidad de trasacciones, pero esto puede mejorar
y tambien dependiendo del enfoque del TFG... Si queremos informar de todo lo 
que pasa a cada instante, puede que no sea lo mas óptimo, pero si el enfoque
es diferente, puede ser la mejor opción y la mejor forma de desarrollarme.

ETHEREUM ALLIANCE: https://entethalliance.org/technical-specifications/
HYPERLEDGER BESU (ETHEREUM ENTERPRISE): https://limechain.tech/blog/hyperledger-besu-explained/
HYPERLEDGER FABRIC: https://github.com/hyperledger/fabric


Ethereum foundation info about different clients:

https://ethereum.org/en/enterprise/private-ethereum/


Buildear Quorum en una Raspberry' (realmente es una modificacion del cliente
Geth... Puedo hacer un prototipo con esto y simplemente usar Geth..., el
problema es la mala velocidad pero esto se solucionaria cambiado el funciona-
miento del proyecto.

https://medium.com/@kavyaub/running-quorum-on-raspberry-pi-e386c1d6fc90



dmesg COMANDO LINUX MUY UTIL A LA HORA DE SABER DONDE SE LOCALIZAN LOS PUERTOS HARDWARE, SERIAL ETC
EN LINUX, UTILIZAR CON EL COMANDO sudo dmseg | tree PARA ASI VER TODO MUCHISIMO MEJOR

			------------------
			sudo	dmesg|tree
			------------------


Desing of Trading Energy System Magnament Using Blockchain Hyperledger Fabric.

	* Encontrado en una busqueda para querer usar los ESP32

"C:\Users\alber\OneDrive\TFG\tfg\bibliografia\Design_of_Trading_Energy_System_Management_Using_Blockchain_Hyperledger_Fabric.pdf"



# BIBLIOGRAFIA ENLACES


