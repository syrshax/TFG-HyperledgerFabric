
Muy importante esto para ejecutar el CLI del peer como admin y poder hacer todas las operaciones necesarias 

``` bash
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_LOCALMSPID="Org1MSP"
export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt
export CORE_PEER_MSPCONFIGPATH=/home/alber/2-red/cryptogen/crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp
export CORE_PEER_ADDRESS=localhost:7051
```


### Este comando para unir al peer con el canal:
```bash
./peer channel join -b ../genesis/genesis_block.pb --tls --cafile ../cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem --certfile ../cryptogen/crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/server.crt --keyfile ../cryptogen/crypto-conf
ig/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/server.key
```

Hay que colocar la identidad de admin *CORE_PEER_MSPCONFIGPATH* a **admin**:
```bash
export CORE_PEER_MSPCONFIGPATH=../cryptogen/crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp

export CORE_PEER_MSPCONFIGPATH=/home/alber/baseproject/cryptogen/crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp
```

/home/alber/baseproject/cryptogen/crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp


## Pasos a seguir para hacer un commit, invoke del chaincode

Para crear el **bloque genesis:**
```bash
./configtxgen -profile ChannelDeveloper -outputBlock genesis_block.pb -channelID channel1
```

Para unir el **orderer con el bloque y crear un canal**
```bash
./osnadmin channel join --channelID channel1  --config-block ../genesis/genesis_block.pb -o 127.0.0.1:6003
```

### Instalar el chaincode en el peer
```bash
./peer lifecycle chaincode install basic.tar.gz
```

### Exportamos la variable CC_PACKAGE_ID
```bash
export CC_PACKAGE_ID= [id del chaincode completo cuando lo instalas]
```


No hace falta que lo aprueben varios peers, ya que la Org1, con que lo apruebe un peer, al cambiar las politicas, seria suficiente.
```bash
./peer lifecycle chaincode approveformyorg -C channel1 -n basic --package-id $CC_PACKAGE_ID --sequence 1 --peerAddresses peer1.org1.example.com:7781 peer0.org1.example.com:7771 -o 127.0.0.1:6001 --ordererTLSHostnameOverride orderer.example.com --version 1.0 --tls --tlsRootCertFiles /home/shadexlinux/2-hyper/cryptogen/crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt /home/shadexlinux/2-hyper/cryptogen/crypto-config/peerOrganizations/org1.example.com/peers/peer1.org1.example.com/tls/ca.crt --cafile /home/shadexlinux/2-hyper/cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem




@ El codigo inferior es para 1 peer, ya que todos estan en la misma org, con que 1 lo apruebe ES SUFICIENTE:

./peer lifecycle chaincode approveformyorg -o localhost:6001 --ordererTLSHostnameOverride orderer.example.com --channelID channel1 --name basic --version 1.0 --package-id $CC_PACKAGE_ID --sequence 1 --tls --cafile /home/alber/2-red/cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem
```

### Para visualizar que org's han aprobado el chaincode en su canal
```bash
./peer lifecycle chaincode checkcommitreadiness --channelID channel1 --name basic --version 1.0 --sequence 1 --tls --cafile /home/alber/2-red/cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem --output json
```




### Con esto, al tener los chaincodes aprobados, hacemos un comit en la Org, aqui si que tenemos que señalar todos los peers de esa organizacion:

```bash
./peer lifecycle chaincode commit -o localhost:6001 --ordererTLSHostnameOverride orderer.example.com --channelID channel1 --name basic --version 1.0 --sequence 1 --tls --cafile /home/alber/2-red/cryptogen/crypto-config/ordererOrganizations/example.com/tlsca/tlsca.example.com-cert.pem --peerAddresses localhost:7051 --tlsRootCertFiles /home/alber/2-red/cryptogen/crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt --peerAddresses localhost:7781 --tlsRootCertFiles /home/shadexlinux/2-hyper/cryptogen/crypto-config/peerOrganizations/org1.example.com/peers/peer1.org1.example.com/tls/ca.crt
```

### Aprobar el chaincode en la org
```bash
 ./peer lifecycle chaincode approveformyorg -o localhost:6001 --ordererTLSHostnameOverride orderer.example.com --channelID channel1 --name golang_example --version 1.0 --package-id $CC_PACKAGE_ID --sequence 1 --tls --cafile /home/shadexlinux/2-hyper/cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem
```

### Ver el status de aprobacion de los chaincodes
```bash
./peer lifecycle chaincode checkcommitreadiness --channelID channel1 --name golang_example --version 1.0 --sequence 1 --tls --cafile /home/alber/2-red/cryptogen/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem --output json
```

### Hacer el commit en los peers definir el chaincode en el canal

```bash
$ Hace faltan los 2 peers


	./peer chaincode invoke -o localhost:6001 --ordererTLSHostnameOverride orderer.example.com --tls --cafile /home/alber/2-red/cryptogen/crypto-config/ordererOrganizations/example.com/tlsca/tlsca.example.com-cert.pem -C channel1 -n basic --peerAddresses localhost:7051 --tlsRootCertFiles /home/alber/2-red/cryptogen/crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt --peerAddresses localhost:9051 --tlsRootCertFiles "${PWD}/organizations/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt" -c '{"function":"InitLedger","Args":[]}'
```

### Ver lo que tenemos en el ledger
```bash
./peer chaincode query -C channel1 -n basic -c '{"Args":["GetAllAssets"]}'
```
