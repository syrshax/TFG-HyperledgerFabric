#### Preguntas 
- Cuales son los tipos de datos en Javascript y Typescript.
- Como se crean funciones en Javascript y Typescript.
- Como se crean metodos en Javascript y Typescript.
- Como se crean clases en Javascript y Typescript.
- Que significa cuando llamas al principio de un archivo
```javascript
const { Contract } = require('fabric-contract-api');
const stringify = require('json-stringify-deterministic');
const sortKeysRecursive = require('sort-keys-recursive');
```
- Que funciones hacen estas librerias:
```javascript
sort-keys-recursive
json-stringify-deterministic
```

- Porqué utilizamos **JAVASCRIPT**
```javascript
//Que significa poner el async delante.
async nameFuncion
class simplecontract extend Contract {
//type somthing here
}
```

- Porque utilizamos en **TYPESCRIPT**
```typescript
import * as grpc from '@grpc/grpc-js';

import * as crypto from 'crypto';

import { connect, Identity, signers, Network, Contract, Gateway} from '@hyperledger/fabric-gateway';

```


### Tipos primitivos en Javascript y Typescript

En **Javascript** tenemos como tipos primitivos, que serian el equivalente a int float double etc en C++ a:

- Number = Representa tanto numeros enteros como coma flotante
- String = Cadenas de texto
- Booleans = Logica, true or false
- Undefined = Valor no asignado
- Null = Valor que representa el vacio
- Symbol = Valor unico e inmutable utilizado como clave para propiedades en objetos
- BigInt = Para representar numeros mayores que un int convencional con *Number*

En **TypeScript** tenemos ademas de los mencionados anteriormente, estos otros:
##### Tipos primitivos extra
- Void = Se tulizan en funciones que no devuelven nada
- Never = Utilizado en valores que no ocurren nunca, sirve como una excepcion
##### Tipos de utilidad
- Any = Para tipos desconocidos dinamicos
-  Unknown = Similar a 'Any', pero mas seguro encuento a tipos
##### Tipos Compuestos
- Tuple = Similar al array, funciona como en Python, tipos de datos conocidos fijos e inmutables
- Enum = Forma de dar nombres a conjuntos de valores numericos o cadena
- Interface y Type Alias = Definen estructuras para objetos y funciones
##### Union e Interseccion
- Union = Permite que un valor sea de uno de varios tipos
- Intersection = Permite combinar multiples tipos en uno
##### Tipos Literales
- String Literal Types = Restringe una cadena para sea de valor especifico. Ex ´Hello'
- Numeric Literal Types = Igual que string pero para Numbers.

### Crear funciones en TypeScript
Para crear funciones en Typescript se puede utilizarla notacion declarada, anonima y flecha.

Todas son igualmente validas y sirven para lo mismo

##### Funcion declarada
```Typescript
function sumTwoNumbers(a: number, b: number): number{
	let result = a + b
	return result
}

const result = function sumTwoNumbers (a: number, b: number): number{
	let result = a + b
	return result
}
```
##### Funcion anonima
```typescript
const sumTwoNumbers = function(a: number, b: number): number{
	let result = a + b
	return result
}

const result = function sumTwoNumbers (a: number, b: number): number{
	let result = a + b
	return result
}

```
##### Funcion flecha
```typescript
const sumTwoNumbers = (a: number, b: number ): number => {
	let result a + b
	return result
}
```

#### Funcion tipo REST
Este tipo de funcion es diferente a las otras, con el operador `...` podemos caputrar un numero variable de argumentos en una funcion, es el operador "rest"

Se ve claro con este ejemplo
```typescript
function sumAllNumbers (...numbers: number[]): number {
	return numbers.reduce((acc,num) => acc + num, 0);
}

Esta funcion recive todos los numeros en la variable numbers, que actua como un vector del tipo: number[]

Posteriormente, utlizamos el metdo reduce. Este metodo utiliza un accumulador y el numero actual, empezando desde 0 en el acumulador.
Esto es realmente un bucle for que hace la suma desde el 1er elemento al ultumo y devuelve un valor. (Internamente no se como funciona, pero algo así es.)
```




