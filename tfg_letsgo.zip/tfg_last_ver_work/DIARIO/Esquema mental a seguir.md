#### POR PULIR...
- Acabar el **estado del arte**, terminar de sacar informacion de diferentes blockchains y DLT's y enlazar con las utilizadades en entornor IoT. **Ver donde entra mejor, si en apartado dentro de Explicacion de Blockchain o fuera.**


#### POR COMENZAR!!!!
-  Comenzar **YA** con la metodologia y estructura. Ir describiendo la arquitectura del sistema con graficos y ir introducciendo Hyperledger y la red mas en profundidad. **UN USUARIO, LEYENDO MI LIBRO TIENE QUE PODER EJECUTAR Y ENTENDER COMPLETAMENTE LOS PASOS, EL PORQUE DE LAS DESICIONES Y PODER MONTAR LA RED EL MISMO.** Con esto, deberia quedar totalmente explicada la metodologia y estructura de trabajo seguida.