
Pagina 19, ejercicio numero 3:

"Do a writting comparing the 2 photos on page 96 using the typical sentences you will use normally for comparing words"


### ESSAY
As we can see in both photos, there are people eating outside. In the top photo, number three, we can identify a family in the woods having a lunch and in the other one we can suspect they are in a restaurant of some sort. Actually they look like having a brunch, as we can see the omelettes and fruit juices, so I suspect that.

The biggest difference for me It's the location. As I said at the beginning, the top photo is located inside a forest meanwhile the group of friends in the second one are probably in a city or town. Sometimes I would love to have a lunch in the woods as in the first photo. The trees, the animals, the environment... all full of nature. My mood changes by just thinking about it.

In the other hand, having a good sized breakfast one day or another doesn't seems a bad idea too. I would change the omelette for a waffle with chocolate syrup or a big pancake. I prefer a sweeter breakfast rather than a salty one.

But at the end in both pictures they're enjoying food and having a good time with friends or family.




