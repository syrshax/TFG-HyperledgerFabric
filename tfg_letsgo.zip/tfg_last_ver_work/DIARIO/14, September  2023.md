Hemos hoy visto **el contrato** y hemos hablado cautelosamente con el jefe. No creo que pueda haber sacado mas de la conversacion.

En el trabajo creo que todo ok.

En lo que al **TFG** se refiere, no he avanzado nada. Tengo que crear un indice en papel (bueno, debería primero estructurarme todo en papel, luego ya vendrá escribir en PC).

Recordemos que la moto