# Obsidian Vault - My private repo for notes.
This is just a private repo for my obsidian notes to be accesible from anywhere.
There is probably private information, so be care when changing rights to make it public.
