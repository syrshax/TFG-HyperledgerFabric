

### 4.1 INTRODUCTION TO DATA TYPES
The list of fundamental data types are:

![[Pasted image 20231101105607.png]]


#### 4.2 VOID

Void significa que no tiene ningun tipo, esta declarado pero no definido.

Las variables no se pueden llamar void.

`void value;` no funciona.

Void se incluye como tipo de funcionque no devuelve nada.
```c++
void wirteValue (int x ){
	std::cout << "The value of x is: " << x << "\n";
}
```


#### Unsigned

Cuando tenemos un valor unsigned y sobrepasamos del maximo permitido, por ejemplo:

- Un valor char tiene un byte = 256 como max, si seleccionamos 257, el compilador hace un **wrap** de la variable, y cuenta como 0, ya que nos hemos pasado, es como si volviese a contar desde la posicion numero 257, que seria un 0. Si guardasemos el valor 258, el valor de la variable tipo char seria de 1. Asi sucesivamente.