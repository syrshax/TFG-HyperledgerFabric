
## 1 - MERCADOS

#### GAS y ELECTRICIDAD
- **Q4-SEPTIEMBRE** = Han recuperado la subida. Las huelgas han marcado la subida. Sigue habiendo volatilidad en el mercado. Se refleja en el mercado de la electricidad. 
- SA y Russia han acordado el recorte de producción hasta final de año.


## 2 - ESTADO DE LAS RENOVACIONES
Peticiones de ofertas lanzadas.


## 3 - ESTADO DE SEGUIMIENTO
Poco a poco, yo sacando fichas con ==@Isabel== 
 - ==SAETILLA GESTION==

## 4 - INCIDENCIAS


## 5 - CAMBIOS LEGISTLATIVOS
NADA POR AHORA, ESPERANDO RESPUESTAS
