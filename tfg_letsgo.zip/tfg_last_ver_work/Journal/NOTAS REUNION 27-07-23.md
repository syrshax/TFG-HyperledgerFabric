### 1º Estado de los mercados
----

Desde la semana pasada ha estado subiendo pero ayer hubo una correccion a a la baja. Subida en **la ultima parte del** **año**

Los derechos de emisión han subido. La electricidad paralelas a los del gas.

La tendencia sigue **a la alta.**

### 2º Renovaciones
----

**Endesa** sigue ofreciendo lo mejor en fijo, mejor que *indexados*

### 3º Seguimiento
----
### 4º Indicencias
--- 
### 5º Observaciones
