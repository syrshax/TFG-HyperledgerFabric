La convergencia de la tecnología del Internet de las Cosas (IoT) y la blockchain está abriendo nuevas fronteras en la forma en que interactuamos y gestionamos los datos en el mundo digital. Los dispositivos IoT encuentran en la blockchain un aliado que asegura integridad, la seguridad y la confiabilidad de la información que manejan.

Los dispositivos IoT desempeñan un papel muy importante en la captura de datos en tiempo real que facilitan la toma de decisiones y las automatizaciones. Al mismo tiempo, la blockchain respalda estos proyectos proporcionando un registro inmutable. Estos dispositivos IoT pueden enviar datos a **redes privadas de blockchain**, creando así registros a prueba de alteraciones que están accesibles unicamente para las entidades configuradas. Esta característica no solo promueve la transparencia sino que también facilita la colaboración y el intercambio de información en un ecosistema donde por ejemplo esten involucrados varios equipos desarrollando un producto, o empresas que deseen compartir informacion confidencial.



Todas las **redes blockchains** no son iguales. Ademas de poder tener tipos de consenso diferentes, protocolos y configuraciones, una de las caracteristicas esenciales que una red blockchain debe tener para participar en entornor IoT es **la velocidad de transaccion o (TX/s)**. 

Como ya se ha comentado previamente, el consenso en las redes blockchains juega un papel muy importante, ya que dependiendo de este, los bloques necesitaran un tipo u otro de 