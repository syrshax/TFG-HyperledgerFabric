
These two pictures shows people using a traveling system. The first one is the train. It's an old system that was invented in the ninetheen century and has a very large capacity of passangers. The second picture shows an airplane. This traveling method is faster than the train, but it's really harmful for the envirnonment. Airplanes emit/a lot of C02 emissions.

If we look closely to the second picture, we can suspect that the passangers using the airplane would travel further than the turists using the train. Normally flights can take you very far and faster than the train so usually if you want to travel far you must book a ticket for it.


