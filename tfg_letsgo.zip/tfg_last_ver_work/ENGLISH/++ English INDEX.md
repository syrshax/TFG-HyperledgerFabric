

### American Psycho Reading

I've started to read the book [[American Psycho]] from Elis Bret Easton.

I'm going to start taking notes about all the words and expressions I didn't know. I'll be re-reading the book alongside my word searching, this way, I'll understand better the meaning of the words/expressions I missed in my first attempt.

I'll be collecting all the words in [[C1 - Expressions, Words, Meanings]] in the [American Psycho] section part of the document. Probably doing it in the Obsidian way, creating an index file for the book in the [[C1 - Expressions, Words, Meanings]] and then linking it to the [[American Psycho]] .

Hope this rutine goes well, I'll be doing it at bed time or afternoon.
